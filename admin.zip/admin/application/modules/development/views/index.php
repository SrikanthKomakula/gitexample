<style>
.center{
	text-align:center;
}
</style>

	<div class="row wrapper border-bottom white-bg page-heading">
		<div class="col-sm-4">
			<h2>Careers</h2>
			<ol class="breadcrumb">
				<li>
					<a href="<?php echo base_url()?>">Dashboard</a>
				</li>
				<li class="active">
					<strong>Careers</strong>
				</li>
			</ol>
		</div>
		<div class="col-sm-4 pull-right">
			<h2>
				<a href="<?php echo base_url()?>index.php/development/createdevelopment" class="btn btn-w-m btn-primary pull-right">Add Description</a>
			</h2>
		</div>
	</div>
	<div class="row">
		<div class="col-lg-12">
			<div class="wrapper wrapper-content">
				<div class="row">
					<div class="ibox">                        
						<div class="ibox-content">
						<?php
						if(@$this->session->userdata("success") != '')
						{
						?>
							<div class="alert alert-success alert-dismissable">
                                <button aria-hidden="true" data-dismiss="alert" class="close" type="button">×</button>
                                <?php
								echo @$this->session->userdata("success");
								@$this->session->unset_userdata("success");
								?>
                            </div>
						<?php
						}
						if(@$this->session->userdata("fail") != '')
						{
						?>
							<div class="alert alert-danger alert-dismissable">
                                <button aria-hidden="true" data-dismiss="alert" class="close" type="button">×</button>
                                <?php
								echo @$this->session->userdata("fail");
								@$this->session->unset_userdata("fail");
								?>
                            </div>
						<?php
						}
						?>
							<table class="table table-striped table-bordered table-hover " id="editable" >
								<thead>
									<tr>
										<th class="center">S.No</th>
										<th class="center" style="width:15%;">Title</th>
										<th class="center" style="width:50%;">Description</th>
										<th class="center" style="width:20%;">Image</th>
										<th class="center" style="width:10%;">Actions</th>
									</tr>
								</thead>
								<tbody>
								<?php
								if(@sizeOf($development) > 0)
								{
									for($a=0;$a<@sizeOf($development);$a++)
									{
								?>
									<tr class="gradeX">
										<td class="center">
											<?php echo @($a+1);?>
										</td>
										<td class="center">
											<?php echo @$development[$a]->cms_title;?>
										</td>
										<td class="center">
											<?php echo @$development[$a]->cms_desc;?>
										</td>
										<td class="center">
											<?php
											if(@$development[$a]->cms_img !='')
											{
											?>
											<img style="margin:0 auto;width:100px;" src="<?php echo base_url();?>uploads/careers/<?php echo @$development[$a]->cms_img;?>" class="img-responsive">
											<?php
											}else{
												echo "N/A";
											}
											?>
										</td>
										<td class="center">
											<a href="<?php echo base_url()?>index.php/development/editdevelopment/<?php echo @$development[$a]->id;?>"><i class="fa fa-edit"></i></a> &nbsp;|&nbsp;
											<a href="<?php echo base_url()?>index.php/development/deletedevelopment/<?php echo @$development[$a]->id;?>"><i class="fa fa-trash"></i></a>
										</td>
									</tr>
								<?php
									}
								}
								else
								{
									echo '<tr class="gradeX"><td colspan="5" style="color:red" class="center"><b>No Records Found</b></td></tr>';
								}
								?>
								</tbody>
							</table>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>

	