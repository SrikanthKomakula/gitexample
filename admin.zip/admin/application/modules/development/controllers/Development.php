<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Development extends MX_Controller {
	public function __construct()
	{
		parent::__construct();
		$this->load->model("development_model");
		//$this->load->model("category/category_model");
	}
	public function index()
	{
		if(@$this->session->userdata("is_logged_in") == 1)
		{
			$data["menu"]="cdw";
			$this->load->view('dashboard/header',$data);
			$data["development"] = $this->development_model->getdevelopment();		
			$this->load->view('index', $data);
			$this->load->view('dashboard/footer');
		}
		else
		{
			redirect(base_url()."index.php/login");
		}
	}
	
	public function createdevelopment()
	{
		if(@$this->session->userdata("is_logged_in") == 1)
		{
			$data["menu"]="cdw";
			$this->load->view('dashboard/header',$data);
			$this->load->view('create-item');
			$this->load->view('dashboard/footer');
		}
		else
		{
			redirect(base_url()."index.php/login");
		}
	}
	
	public function savedevelopment()
	{
		if($_FILES["mainImage"]["name"] !='')
		{
			$global=explode(".",$_FILES["mainImage"]["name"]);
			$banner_img=time().".".end($global);
		}
		else
		{
			$banner_img="";
		}
		$params = array(			
			"cms_title" => $this->input->post("cms_title"),			
			"cms_desc" => $this->input->post("cms_desc"),			
			"cms_img" => $banner_img,			
			"page_type" => 6,			
			"created_date" => @date("Y-m-d H:i:s"),
		);
		$table="wallsasia_cms";
		$indevelopmentt = $this->development_model->storeItems($table,$params);
		if($indevelopmentt == 1)
		{
			@move_uploaded_file($_FILES["mainImage"]["tmp_name"],"uploads/careers/".$banner_img);
			$this->session->set_userdata(array(
				"success" => "Successfully Saved Data"
			));
			redirect(base_url()."index.php/development");
		}
		else{
			$this->session->set_userdata(array(
				"faile" => "Failed to save the data"
			));
			redirect(base_url()."index.php/development");
		}
	}
	
	public function editdevelopment($bannerid)
	{
		if(@$this->session->userdata("is_logged_in") == 1)
		{
			$data["menu"]="cdw";
			$this->load->view('dashboard/header',$data);
			$data["info"]=$this->development_model->getInfobyId($bannerid);
			$data["bannerid"]=$bannerid;
			
			$this->load->view('edit-item',$data);
			$this->load->view('dashboard/footer');
		}
		else
		{
			redirect(base_url()."index.php/login");
		}
	}
	
	public function updatedevelopment()
	{
		if($this->session->userdata("is_logged_in") != 1)
		{
			redirect(base_url()."index.php/login");
		}
		else
		{	
			$bannerid=$this->input->post("developmentid");
			
			if(@$_FILES["mainImage"]["name"] != '')
			{
				$category=explode(".",$_FILES["mainImage"]["name"]);
				$banner_img=time().".".end($category);
			
				$deleteExistimage=$this->development_model->removeExistsimage($bannerid);
								
				@move_uploaded_file($_FILES["mainImage"]["tmp_name"],"uploads/careers/".$banner_img);
						
			}
			else
			{
				$banner_img=$this->input->post("hiddenmainImage");
			}
			
			$params=array(				
				"cms_title" => $this->input->post("cms_title"),			
				"cms_desc" => $this->input->post("cms_desc"),			
				"cms_img" => $banner_img,
				"page_type" => 6,				
			);
			//print_r($params);die();
			$table="wallsasia_cms";
			$development=$this->development_model->updateItems($table,$params,$bannerid);
			if($development == 1)
			{
				$this->session->set_userdata(array(
					"success" => "Successfully Data Updated"
				));
				redirect(base_url()."index.php/development");
			}
			else
			{
				$this->session->set_userdata(array(
					"faile" => "Failed to Update data"
				));				
				redirect(base_url()."index.php/development");
			}
			
		}
	}
	
	public function deletedevelopment($bannerid)
	{
		//$bannerid=str_replace("_","=",base64_decode($bannerid));		
		$test=$this->development_model->deletedevelopment($bannerid);
		if($test == 1)
		{
			$this->session->set_userdata(array(
				"success" => "Successfully Deleted"
			));
			redirect(base_url()."index.php/development");
		}
		else
		{
			$this->session->set_userdata(array(
					"faile" => "Failed to Delete data"
				));				
			redirect(base_url()."index.php/development");
		}
		
	}
	
}
