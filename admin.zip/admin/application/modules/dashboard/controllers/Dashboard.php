<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Dashboard extends MX_Controller {
	public function __construct()
	{
		parent::__construct();
		$this->load->model("dashboard_model");
	}
	public function index()
	{
		if(@$this->session->userdata("is_logged_in") == 1)
		{
			$data["menu"]="homeact";
			$this->load->view('header',$data);
			$this->load->view('index');
			$this->load->view('footer');
		}
		else
		{
			redirect(base_url()."index.php/login");
		}
	}
	
	public function changePassword()
	{
		if($this->session->userdata("is_logged_in") != 1)
		{
			redirect(base_url()."index.php/login");
		}
		else
		{
			
			$this->load->view('header');
			$this->load->view('changepassword');
			$this->load->view('footer');
		}
	}

	public function update()
	{
		$params=array(
			'password' => SHA1($this->input->post("npassword"))
		);
		
		$update=$this->dashboard_model->update($params,$this->session->userdata("userid"));
		if($update == 1)
		{
			$this->session->set_userdata(array(
					"sucess" => "Your Password Has Been Sucessfully Changed. Please Login To Continue"
			));
			redirect(base_url()."index.php/login/logout");
		}
		else
		{
			$this->session->set_userdata(array(
					"fail" => "Failed to Update Password"
			));
			redirect(base_url()."index.php/dashboard/changePassword");
		}
	}
	
	public function customers(){
	    	if(@$this->session->userdata("is_logged_in") == 1)
		{
			$data["menu"]="customers";
			$this->load->view('header',$data);
			$data["customers"] = $this->dashboard_model->getcustomers();
			$this->load->view('customers', $data);
			$this->load->view('footer');
		}
		else
		{
			redirect(base_url()."index.php/login");
		}
	}
	
	public function deletecustomer($bannerid)
	{
		//$bannerid=str_replace("_","=",base64_decode($bannerid));		
		$test=$this->dashboard_model->deletecustomer($bannerid);
		if($test == 1)
		{
			$this->session->set_userdata(array(
				"success" => "Successfully Deleted"
			));
			redirect(base_url()."index.php/customers");
		}
		else
		{
			$this->session->set_userdata(array(
					"faile" => "Failed to Delete data"
				));				
			redirect(base_url()."index.php/customers");
		}
		
	}
	
}
