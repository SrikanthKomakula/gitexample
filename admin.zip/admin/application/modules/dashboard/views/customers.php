<style>
.center{
	text-align:center;
}
</style>
<link href="<?php echo base_url()?>externals/css/plugins/dataTables/dataTables.bootstrap.css" rel="stylesheet">
<link href="<?php echo base_url()?>externals/css/plugins/dataTables/dataTables.responsive.css" rel="stylesheet">
<link href="<?php echo base_url()?>externals/css/plugins/dataTables/dataTables.tableTools.min.css" rel="stylesheet">
	<div class="row wrapper border-bottom white-bg page-heading">
		<div class="col-sm-4">
			<h2>Customers</h2>
			<ol class="breadcrumb">
				<li>
					<a href="<?php echo base_url()?>">Dashboard</a>
				</li>
				<li class="active">
					<strong>Customers</strong>
				</li>
			</ol>
		</div>
		<div class="col-sm-4 pull-right">
			<h2>
		
			</h2>
		</div>
	</div>
	<div class="row">
		<div class="col-lg-12">
			<div class="wrapper wrapper-content">
				<div class="row">
					<div class="ibox">                        
						<div class="ibox-content">
						<?php
						if(@$this->session->userdata("success") != '')
						{
						?>
							<div class="alert alert-success alert-dismissable">
                                <button aria-hidden="true" data-dismiss="alert" class="close" type="button">×</button>
                                <?php
								echo @$this->session->userdata("success");
								@$this->session->unset_userdata("success");
								?>
                            </div>
						<?php
						}
						if(@$this->session->userdata("fail") != '')
						{
						?>
							<div class="alert alert-danger alert-dismissable">
                                <button aria-hidden="true" data-dismiss="alert" class="close" type="button">×</button>
                                <?php
								echo @$this->session->userdata("fail");
								@$this->session->unset_userdata("fail");
								?>
                            </div>
						<?php
						}
						?>
						<!--	<div class="row">
								<form method="POST" action="<?php echo base_url()?>index.php/teachers/savesubmenu" class="form-horizontal" enctype="multipart/form-data">
									<div class="form-group">
										<label class="col-sm-3 control-label">Sub Menu Name</label>
										<div class="col-sm-3">
											<input type="text" name="menu_name" id="menu_name" value="<?php// echo @$subMenu[0]->menu_name?>" class="form-control txtcls" required maxlength="15"/>
											<span id="cond" style="color: red;font-size:13px;">*Max Name length 15 characters.</span>
										</div>
										<div class="col-sm-3">
											<input type="hidden" name="aboutid" id="aboutid" value="<?php// echo @$subMenu[0]->id?>"/>
											<button class="btn btn-primary" type="submit">Update</button>
										</div>
									</div>									
									<div class="hr-line-dashed"></div>
								</form>
							</div>-->
							<table class="table table-striped table-bordered table-hover " id="editable" >
								<thead>
									<tr>
										<th class="center">S.No</th>
										<th class="center">Customer Name</th>
										<th class="center">Email ID</th>
										<th class="center">Phone Number</th>
										<th class="center">Address</th>
										<th class="center">Status</th>
										<th class="center">Action</th>
									</tr>
								</thead>
								<tbody>
								<?php
								if(@sizeOf($customers) > 0)
								{
									for($a=0;$a<@sizeOf($customers);$a++)
									{
								?>
									<tr class="gradeX">
										<td class="center">
											<?php echo @($a+1);?>
										</td>
									
										<td class="center">
											<?php echo @$customers[$a]->FName.' '.@$customers[$a]->LName;?>
										</td>
										<td class="center">
											<?php echo @$customers[$a]->Email;?>
										</td>
										<td class="center">
											<?php echo @$customers[$a]->Phone;?>
										</td>
										<td class="center">
											<?php echo @$customers[$a]->Address;?>, <?php echo @$customers[$a]->Address;?>, <?php echo @$customers[$a]->Postcode;?>
										</td>
										<td class="center">
											<?php echo @$customers[$a]->Status;?>
										</td>
									
										<td class="center">
											
											<a href="<?php echo base_url()?>index.php/customers/deletecustomer/<?php echo @$customers[$a]->ID;?>"><i class="fa fa-trash"></i></a>
										</td>
									</tr>
								<?php
									}
								}								
								?>
								</tbody>
							</table>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>

<script src="<?php echo base_url()?>externals/js/plugins/jeditable/jquery.jeditable.js"></script>
<script src="<?php echo base_url()?>externals/js/plugins/dataTables/jquery.dataTables.js"></script>
<script src="<?php echo base_url()?>externals/js/plugins/dataTables/dataTables.bootstrap.js"></script>
<script src="<?php echo base_url()?>externals/js/plugins/dataTables/dataTables.responsive.js"></script>
<script src="<?php echo base_url()?>externals/js/plugins/dataTables/dataTables.tableTools.min.js"></script>
<script>
$(document).ready(function() {
	$('.dataTables-example').dataTable({
		responsive: true,
		"dom": 'T<"clear">lfrtip',
		"tableTools": {
			"sSwfPath": "js/plugins/dataTables/swf/copy_csv_xls_pdf.swf"
		}
	});

	/* Init DataTables */
	var oTable = $('#editable').dataTable();

	/* Apply the jEditable handlers to the table */
	/*oTable.$('td').editable( '../example_ajax.php', {
		"callback": function( sValue, y ) {
			var aPos = oTable.fnGetPosition( this );
			oTable.fnUpdate( sValue, aPos[0], aPos[1] );
		},
		"submitdata": function ( value, settings ) {
			return {
				"row_id": this.parentNode.getAttribute('id'),
				"column": oTable.fnGetPosition( this )[2]
			};
		},

		"width": "90%",
		"height": "100%"
	} );*/


});

function fnClickAddRow() {
	$('#editable').dataTable().fnAddData( [
		"Custom row",
		"New row",
		"New row",
		"New row",
		"New row" ] );

}
$(".bha-ord").click(function(){
	var clickId=$(this).attr("id");
	if(clickId !='')
	{
		$.ajax({
			type:"POST",
			url:'<?php echo base_url();?>index.php/teachers/getClassOrder/'+clickId,
			async:false,
			success:function(response){				
				$("#ordModal").modal();
				$("#ordData").html(response);
			}			
		})
		
	}
});
</script>


<!-- Description Modal Starts --> 
<div id="ordModal" class="modal fade" role="dialog">
	<div class="modal-dialog">
		<!-- Modal content-->
		<div class="modal-content" style="border-radius:0;">
		<div class="modal-header">
			<button type="button" class="close" data-dismiss="modal">&times;</button>
			<h4 class="modal-title">Description</h4>
		</div>
		<div class="modal-body">
			<div id="ordData"></div>		
		</div>
		<div class="modal-footer">
			
		</div>
    </div>
	
  </div>
</div>
<!-- End of Description Modal --> 