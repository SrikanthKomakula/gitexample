				
			</div>
		</div>

	</div>
		
</div>

    <!-- Mainly scripts -->
    


<script src="<?php echo base_url()?>externals/js/inspinia.js"></script>
  

	
</body>
</html>
 	
    
   