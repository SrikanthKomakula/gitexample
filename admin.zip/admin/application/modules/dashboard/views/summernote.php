<script src="<?php echo base_url()?>externals/js/jquery-2.1.1.js"></script>
    <script src="<?php echo base_url()?>externals/js/bootstrap.min.js"></script>
    <script src="<?php echo base_url()?>externals/js/plugins/metisMenu/jquery.metisMenu.js"></script>
    <script src="<?php echo base_url()?>externals/js/plugins/slimscroll/jquery.slimscroll.min.js"></script>

    

    <!-- SUMMERNOTE -->
    <script src="<?php echo base_url()?>externals/js/plugins/summernote/summernote.min.js"></script>