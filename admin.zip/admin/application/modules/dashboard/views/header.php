<!DOCTYPE html>
<html>
<head>
   <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hikeassets | Dashboard</title>
     <link href="<?php echo base_url()?>externals/css/bootstrap.min.css" rel="stylesheet">
    <link href="<?php echo base_url()?>externals/font-awesome/css/font-awesome.css" rel="stylesheet">
	<link href="<?php echo base_url()?>externals/css/plugins/chosen/chosen.css" rel="stylesheet">
    <!-- Toastr style -->
    <link href="<?php echo base_url()?>externals/css/plugins/toastr/toastr.min.css" rel="stylesheet">

    <!-- Gritter -->
    <link href="<?php echo base_url()?>externals/js/plugins/gritter/jquery.gritter.css" rel="stylesheet">
	<link href="<?php echo base_url()?>externals/css/plugins/steps/jquery.steps.css" rel="stylesheet">
    <link href="<?php echo base_url()?>externals/css/animate.css" rel="stylesheet">
    <link href="<?php echo base_url()?>externals/css/style.css" rel="stylesheet">	
	<script src="<?php echo base_url()?>externals/js/jquery-2.1.1.js"></script>
    <script src="<?php echo base_url()?>externals/js/bootstrap.min.js"></script>
    <script src="<?php echo base_url()?>externals/js/plugins/metisMenu/jquery.metisMenu.js"></script>
    <script src="<?php echo base_url()?>externals/js/plugins/slimscroll/jquery.slimscroll.min.js"></script>
	<link rel="stylesheet" href="<?php echo base_url();?>externals/css/jquery.mCustomScrollbar.css">
	<script type="text/javascript">
		var baseurl="<?php echo base_url()?>";
	</script>
</head>


<body>
    <div id="wrapper">
        <nav class="navbar-default navbar-static-side" role="navigation">
            <div class="sidebar-collapse">
                <ul class="nav" id="side-menu">
					<li class="nav-header">
                        <div class="dropdown profile-element"> <span>
                            <!--<img alt="image" class="img-circle" src="<?php echo base_url()?>externals/img/profile_small.jpg" />-->
                             </span>
                            <a data-toggle="dropdown" class="dropdown-toggle" href="#">
                            <span class="clear"> <span class="block m-t-xs"> <strong class="font-bold"><?php echo @$this->session->userdata("firstname")." ".@$this->session->userdata("lastname");?></strong>
							<?php
								if(@$this->session->userdata("usertype") == "1" )
								{
									$reso="Super Admin";
								}
								elseif(@$this->session->userdata("usertype") == "2")
								{
									$reso="Admin";
								}
								else{
									
									$reso="Vendor";
								}
							?>
                             </span> <span class="text-muted text-xs block"><?php echo @$reso;?> <b class="caret"></b></span> </span> </a>
                            <ul class="dropdown-menu animated fadeInRight m-t-xs">
                                <li><a href="<?php echo base_url()?>index.php/dashboard/changepassword">Change Password</a></li>
                                <li><a href="<?php echo base_url()?>index.php/login/logout">Logout</a></li>
                            </ul>
                        </div>
                    </li>
                   
				<?php				
				if(@$this->session->userdata("usertype") == "1" || @$this->session->userdata("usertype") == "2")			
				{
				?>
				<li class="<?php if(@$menu == "users"){echo "active";}?>">
                        <a href="<?php echo base_url()?>index.php/users"><i class="fa fa-building"></i> <span class="nav-label">Users</span></a>
				</li>
				
				<li class="<?php if(@$menu == "properties"){echo "active";}?>">
                        <a href="<?php echo base_url()?>index.php/properties"><i class="fa fa-building"></i> <span class="nav-label">Properties</span></a>
				</li>
				
				<li class="<?php if(@$menu == "visit_cust"){echo "active";}?>">
                        <a href="<?php echo base_url()?>index.php/visit_cust"><i class="fa fa-building"></i> <span class="nav-label">Customer Visit</span></a>
                        
                <li class="<?php if(@$menu == "bank_loans"){echo "active";}?>">
                        <a href="<?php echo base_url()?>index.php/bank_loans"><i class="fa fa-building"></i> <span class="nav-label">Bank Loans</span></a>
                        
                <li class="<?php if(@$menu == "legal_opinion"){echo "active";}?>">
                        <a href="<?php echo base_url()?>index.php/legal_opinion"><i class="fa fa-building"></i> <span class="nav-label">Legal Opinion</span></a>
				</li>
				
				 <li class="<?php if(@$menu == "legal_opinion"){echo "active";}?>">
                        <a href="<?php echo base_url()?>index.php/properties/buy_quote"><i class="fa fa-building"></i> <span class="nav-label">Buy Property Quote</span></a>
				</li>
				
				
				<?php
				}
				?>
                </ul>
            </div>
        </nav>
		
		

		<div id="page-wrapper" class="gray-bg dashbard-1">
			<div class="row border-bottom">
				<nav class="navbar navbar-static-top" role="navigation" style="margin-bottom: 0">
					<div class="navbar-header">
						<a class="navbar-minimalize minimalize-styl-2 btn btn-primary" href="#"><i class="fa fa-bars"></i> </a>
					</div>
					<ul class="nav navbar-top-links navbar-right">
						<li>
							<span class="m-r-sm text-muted welcome-message">Welcome to Hikeassets Admin Panel.</span>
						</li>
						<li>
							<a href="<?php echo base_url()?>index.php/login/logout">
								<i class="fa fa-sign-out"></i> Log out
							</a>
						</li>
					</ul>
				</nav>
			</div>