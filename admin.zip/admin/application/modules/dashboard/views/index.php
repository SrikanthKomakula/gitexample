<style>
.bhanuTop{
	margin-top:10%;
}
</style>
 
<div class="wrapper wrapper-content">
	<div class="row bhanuTop">
		<h2 style="text-align:center;">Welcome To Hikeassets Admin Panel</h2>
	</div> 
</div>