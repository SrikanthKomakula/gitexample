<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Dashboard_model extends CI_Model {

	public function update($params,$userid)
	{
		$query=$this->db->update("users",$params,array("id" => $userid));
		if($query)
		{
			return 1;
		}
		else{
			return 0;
		}
	}
	
		public function getcustomers()
	{
		$this->db->select("*")->from("customers");		
		$query=$this->db->get();
		if($query->num_rows() > 0)
		{
			return $query->result();
		}
		else{
			return array();
		}
	}
	
	public function deletecustomer($bannerid)
	{		
		
		$deletequery=$this->db->delete("customers",array("ID" => $bannerid));
		if($deletequery)
		{
			return 1;
		}
		else
		{
			return 0;
		}
	}
	
	
}