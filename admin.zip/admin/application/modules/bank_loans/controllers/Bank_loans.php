<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Bank_loans extends MX_Controller {
	public function __construct()
	{
		parent::__construct();
		$this->load->model("bank_loans_model");
		//$this->load->model("category/category_model");
	}
	public function index()
	{
		if(@$this->session->userdata("is_logged_in") == 1)
		{
			$data["menu"]="bank_loans";
			$this->load->view('dashboard/header',$data);
			$data["bank_loans"] = $this->bank_loans_model->getvisit_cust();
			
			$this->load->view('index', $data);
			$this->load->view('dashboard/footer');
		}
		else
		{
			redirect(base_url()."index.php/login");
		}
	}

	
	
	public function edit_bank_loans($bannerid)
	{
		if(@$this->session->userdata("is_logged_in") == 1)
		{
			$data["menu"]="visit_cust";
			$this->load->view('dashboard/header',$data);
			$data["info"]=$this->bank_loans_model->getInfobyId($bannerid);
			$data["bannerid"]=$bannerid;
			
			$this->load->view('edit-item',$data);
			$this->load->view('dashboard/footer');
		}
		else
		{
			redirect(base_url()."index.php/login");
		}
	}
	
	public function updatebank_loans()
	{
		if($this->session->userdata("is_logged_in") != 1)
		{
			redirect(base_url()."index.php/login");
		}
		else
		{	
			$bannerid=$this->input->post("bank_loan_id");
			
			
			$params=array(				
				"feedback" => $this->input->post("feedback"),	
				"interested" => $this->input->post("interested"),	
			);
			//print_r($params);die();
			$table="bank_loans";
			$teachers=$this->bank_loans_model->updateItems($table,$params,$bannerid);
			if($teachers == 1)
			{
				$this->session->set_userdata(array(
					"success" => "Successfully Data Updated"
				));
				redirect(base_url()."index.php/bank_loans");
			}
			else
			{
				$this->session->set_userdata(array(
					"faile" => "Failed to Update data"
				));				
				redirect(base_url()."index.php/bank_loans");
			}
			
		}
	}
	
	public function delete_bank_loans($bannerid)
	{
		$test=$this->bank_loans_model->deletevisit_cust($bannerid);
		if($test == 1)
		{
			$this->session->set_userdata(array(
				"success" => "Successfully Deleted"
			));
			redirect(base_url()."index.php/bank_loans");
		}
		else
		{
			$this->session->set_userdata(array(
					"faile" => "Failed to Delete data"
				));				
			redirect(base_url()."index.php/bank_loans");
		}
		
	}
	
	
}
