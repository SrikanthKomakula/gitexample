<style>
.center{
	text-align:center;
}
</style>
<link href="<?php echo base_url()?>externals/css/plugins/dataTables/dataTables.bootstrap.css" rel="stylesheet">
<link href="<?php echo base_url()?>externals/css/plugins/dataTables/dataTables.responsive.css" rel="stylesheet">
<link href="<?php echo base_url()?>externals/css/plugins/dataTables/dataTables.tableTools.min.css" rel="stylesheet">

	<div class="row wrapper border-bottom white-bg page-heading">
		<div class="col-sm-4">
			<h2>Bank Loans</h2>
			<ol class="breadcrumb">
				<li>
					<a href="<?php echo base_url()?>">Dashboard</a>
				</li>
				<li class="active">
					<strong>Bank Loans</strong>
				</li>
			</ol>
		</div>
	</div>
	<div class="row">
		<div class="col-lg-12">
			<div class="wrapper wrapper-content">
				<div class="row">
					<div class="ibox">                        
						<div class="ibox-content">
						<?php
						if(@$this->session->userdata("success") != '')
						{
						?>
							<div class="alert alert-success alert-dismissable">
                                <button aria-hidden="true" data-dismiss="alert" class="close" type="button">×</button>
                                <?php
								echo @$this->session->userdata("success");
								@$this->session->unset_userdata("success");
								?>
                            </div>
						<?php
						}
						if(@$this->session->userdata("fail") != '')
						{
						?>
							<div class="alert alert-danger alert-dismissable">
                                <button aria-hidden="true" data-dismiss="alert" class="close" type="button">×</button>
                                <?php
								echo @$this->session->userdata("fail");
								@$this->session->unset_userdata("fail");
								?>
                            </div>
						<?php
						}
						?>
							<table class="table table-striped table-bordered table-hover " id="editable" >
								<thead>
									<tr>
										<th class="center">S.No</th>
										<th class="center">Customer Name</th>
										<th class="center">Customer Email</th>
										<th class="center">Customer Phone</th>
										<th class="center">Property Selected</th>
										<th class="center">Message</th>
										<th class="center">Feedback</th>
										<th class="center">Filled On</th>
										<th class="center">Actions</th>
									</tr>
								</thead>
								<tbody>
								<?php
								if(@sizeOf($bank_loans) > 0)
								{
									for($a=0;$a<@sizeOf($bank_loans);$a++)
									{
								?>
									<tr class="gradeX">
										<td class="center">
											<?php echo @($a+1);?>
										</td>
										<td class="center">
										<?php echo @$bank_loans[$a]->user_name;?>
										</td>

                                        <td class="center">
											<?php echo @$bank_loans[$a]->user_email;?>
										</td>										<td class="center">
											<?php echo @$bank_loans[$a]->user_phone;?>
										</td>
										<td class="center">
											<?php echo @$bank_loans[$a]->property_selected;?>
										</td>
										<td class="center">
											<?php echo @$bank_loans[$a]->user_message;?>
										</td>
										<td class="center">
											<?php echo @$bank_loans[$a]->feedback;?> 
										</td>
										<td class="center">
											<?php echo @$bank_loans[$a]->created_date;?> 
										</td>
										<td class="center">
										    <?php if(@$bank_loans[$a]->interested == "yes"){
										    echo '<i class="fa fa-check"></i>';
										    } ?>
										    
											<a href="<?php echo base_url()?>index.php/bank_loans/delete_bank_loans/<?php echo @$bank_loans[$a]->id;?>"><i class="fa fa-trash"></i></a>
											
											<a href="<?php echo base_url()?>index.php/bank_loans/edit_bank_loans/<?php echo @$bank_loans[$a]->id;?>"><i class="fa fa-edit"></i></a>
											
										</td>
									</tr>
								<?php
									}
								}
								else
								{
									echo '<tr class="gradeX"><td colspan="5" style="color:red" class="center"><b>No Records Found</b></td></tr>';
								}
								?>
								</tbody>
							</table>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>

<script src="<?php echo base_url()?>externals/js/plugins/jeditable/jquery.jeditable.js"></script>
<script src="<?php echo base_url()?>externals/js/plugins/dataTables/jquery.dataTables.js"></script>
<script src="<?php echo base_url()?>externals/js/plugins/dataTables/dataTables.bootstrap.js"></script>
<script src="<?php echo base_url()?>externals/js/plugins/dataTables/dataTables.responsive.js"></script>
<script src="<?php echo base_url()?>externals/js/plugins/dataTables/dataTables.tableTools.min.js"></script>
<script>
$(document).ready(function() {
	$('.dataTables-example').dataTable({
		responsive: true,
		"dom": 'T<"clear">lfrtip',
		"tableTools": {
			"sSwfPath": "js/plugins/dataTables/swf/copy_csv_xls_pdf.swf"
		}
	});

	/* Init DataTables */
	var oTable = $('#editable').dataTable();

	/* Apply the jEditable handlers to the table */
	/*oTable.$('td').editable( '../example_ajax.php', {
		"callback": function( sValue, y ) {
			var aPos = oTable.fnGetPosition( this );
			oTable.fnUpdate( sValue, aPos[0], aPos[1] );
		},
		"submitdata": function ( value, settings ) {
			return {
				"row_id": this.parentNode.getAttribute('id'),
				"column": oTable.fnGetPosition( this )[2]
			};
		},

		"width": "90%",
		"height": "100%"
	} );*/


});

function fnClickAddRow() {
	$('#editable').dataTable().fnAddData( [
		"Custom row",
		"New row",
		"New row",
		"New row",
		"New row" ] );

}
</script>
	