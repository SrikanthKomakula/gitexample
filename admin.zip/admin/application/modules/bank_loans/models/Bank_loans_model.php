<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Bank_loans_model extends CI_Model {
    
    
    
    
    
    function __construct() { 
        // Set table name 
    } 
    
		public function getvisit_cust()
	{
	    
		
		$this->db->select('*,a.created_date as cc');
    $this->db->from('bank_loans a'); 
    $this->db->order_by('a.id','desc');         
    $query = $this->db->get(); 
    if($query->num_rows() != 0)
    {
        return $query->result();
    }
    else
    {
        return false;
    }
	}
	
	public function getSubmenu()
	{
		$this->db->select("*")->from("sub_menu")->where(array("page_type" => 1));		
		$query=$this->db->get();
		if($query->num_rows() > 0)
		{
			return $query->result();
		}
		else{
			return array();
		}
	}
	
	public function storeItems($table,$params)
	{
		$query=$this->db->insert($table,$params);
		if($query)
		{
			return 1;
		}
		else{
			return 0;
		}
	}
	
	public function updateItems($table,$params,$bannerid)
	{
		$query=$this->db->update($table,$params,array("id" => $bannerid));
		if($query)
		{
			return 1;
		}
		else{
			return 0;
		}
	}
	
	public function getInfobyId($bannerid)
	{
		$query = $this->db->select("*")->from("bank_loans")->where("id",$bannerid)->get();
		if($query->num_rows() > 0)
		{
			return $query->result();
		}
		else{
			return array();
		}
	}
	
	public function deletevisit_cust($bannerid)
	{		
		$deletequery=$this->db->delete("bank_loans",array("id" => $bannerid));
		if($deletequery)
		{
			return 1;
		}
		else
		{
			return 0;
		}
	}
	
	public function removeExistsimage($bannerid)
	{
		$this->db->select("*")->from("process")->where(array("id" => $bannerid));
		$query=$this->db->get();
		//echo $this->db->last_query();die();
		if($query->num_rows() > 0)
		{
			$result=$query->result();		
			$delete=@unlink(FCPATH . 'uploads/process/' . $result[0]->icon);
			if($delete)
			{
				return 1;
			}
			else
			{
				return 0;
			}
		}
	}
	
	
	 public function getPropertybyID($id = ''){ 
        $this->db->select("*, (SELECT file_name FROM ".$this->imgTbl." WHERE property_id = ".$this->galleryTbl.".id ORDER BY id DESC LIMIT 1) as default_image"); 
        $this->db->from($this->galleryTbl); 
        if($id){ 
            $this->db->where('id', $id); 
            $query  = $this->db->get(); 
            $result = ($query->num_rows() > 0)?$query->row_array():array(); 
             
            if(!empty($result)){ 
                $this->db->select('*'); 
                $this->db->from($this->imgTbl); 
                $this->db->where('property_id', $result['id']); 
                $this->db->order_by('id', 'desc'); 
                $query  = $this->db->get(); 
                $result2 = ($query->num_rows() > 0)?$query->result_array():array(); 
                $result['images'] = $result2;  
                
                
            }  
        }else{ 
            $this->db->order_by('id', 'desc'); 
            $query  = $this->db->get(); 
            $result = ($query->num_rows() > 0)?$query->result_array():array(); 
        } 
         
        // return fetched data 
        return !empty($result)?$result:false; 
    } 
    
     /*Delete property row*/
     public function delete($id){ 
        // Delete gallery data 
        $delete = $this->db->delete($this->galleryTbl, array('id' => $id)); 
         
        // Return the status 
        return $delete?true:false; 
    } 
    
     /* 
     * Delete image data from the database 
     * @param array filter data based on the passed parameter 
     */ 
    public function deleteImage($con){ 
        // Delete image data 
        $delete = $this->db->delete($this->imgTbl, $con); 
         
        // Return the status 
        return $delete?true:false; 
    } 
    
    
	
}