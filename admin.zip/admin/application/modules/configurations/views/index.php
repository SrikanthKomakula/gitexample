
	<div class="row wrapper border-bottom white-bg page-heading">
		<div class="col-sm-4">
			<h2>Configuration Settings</h2>
			<ol class="breadcrumb">
				<li>
					<a href="<?php echo base_url()?>">Dashboard</a>
				</li>
				<li class="active">
					<strong>Configuration Settings</strong>
				</li>
			</ol>
		</div>
	</div>
	<div class="row">
		<div class="col-lg-12">
			<div class="wrapper wrapper-content">
				<div class="row">
					<div class="ibox">
                        
						<div class="ibox-content">
							
							<form id="form" method="POST" action="<?php echo base_url()?>index.php/configurations/saveSettings" class="wizard-big">
								<h1>Site Details</h1>
								<fieldset>
									<h2>Site Name</h2>
									<div class="row">
										<div class="col-lg-8">
											<div class="form-group">
												<input id="sitename" name="sitename" type="text" value="<?php echo @$sitename[0]->configValue?>" placeholder="Enter Site Name" class="form-control required" required />
											</div>
										</div>
									</div>

								</fieldset>
								<h1>Category Levels</h1>
								<fieldset>
									<h2>Category Tree</h2>
									<div class="row">
										<div class="col-lg-6">
											<div class="form-group">
												<label>No of Category Levels *</label>
												<input id="menuLevel" name="menuLevel" type="text" value="<?php echo @$menutree[0]->configValue?>" class="form-control required">
											</div>
										</div>
									</div>
								</fieldset>

								<h1>Integrations</h1>
								<fieldset>
									<div class="text-center" style="margin-top: 120px">
										<h2>SMS API Details</h2>
										<div class="row">
											<div class="col-lg-12">
												<div class="form-group">
													<label>SMS API URL *</label>
													<?php
													$sms=@json_decode($smsIntegration[0]->configValue);
													//print_R($sms[0]->smsapi->apiurl);
													?>
													<input id="smsapi" name="smsapi" type="text" value="<?php echo @$sms[0]->smsapi->apiurl;?>" class="form-control required">
												</div>
											</div>
										</div>
										
									</div>
								</fieldset>

								<h1>Payment Gateways</h1>
								<fieldset>
									
										<div class="row">
											
											<div class="col-lg-6">
											<?php
											$paymentGateway=@json_decode($paymentGateway[0]->configValue);
											//print_R($paymentGateway);
											?>
												<h2>CCAVENUE</h2>
												<div class="form-group">
													<label>Business Email Id *</label>
													<input id="businessEmail" name="businessEmail" type="text" value="<?php echo $paymentGateway[0]->ccavenue->businessEmail?>" class="form-control required">
												</div>
												<div class="form-group">
													<label>CCAVENUE Password *</label>
													<input id="ccavenuePwd" name="ccavenuePwd" type="text" value="<?php echo $paymentGateway[0]->ccavenue->password?>" class="form-control required">
												</div>
												<div class="form-group">
													<label>Working Key *</label>
													<input id="workingKey" name="workingKey" type="text" value="<?php echo $paymentGateway[0]->ccavenue->workingkey?>" class="form-control required">
												</div>
												<div class="form-group">
													<label>Access Key *</label>
													<input id="accessKey" name="accessKey" type="text" value="<?php echo $paymentGateway[0]->ccavenue->accesskey?>" class="form-control required">
												</div>
											</div>
											
											<div class="col-lg-6">
												<h2>PAYPAL</h2>
												<div class="form-group">
													<label>Business Email Id *</label>
													<input id="paypalBusinessEmail" name="paypalBusinessEmail" value="<?php echo $paymentGateway[0]->paypal->businessEmail?>" type="text" class="form-control required">
												</div>
											</div>
										</div>
								</fieldset>
							</form>
						</div>
					</div>
				</div>
			</div>
			