<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Configurations_model extends CI_Model {

	public function storeConfigurations($params)
	{
		//echo "<pre>"; print_r($params);echo "</pre>";
		$setter = 0;
		$sitename = $params["sitename"];
		$menutree = $params["menutree"];
		$smsIntegration = json_encode(array($params["smsIntegration"]));
		$paymentGateway = json_encode(array($params["paymentGateway"]));
		
		$qry = $this->db->select("*")->from("configurations")->get();
		if($qry->num_rows() > 0)
		{
			$query=$this->db->update("configurations",array("configValue" => $sitename),array("configTitle" => "sitename"));
			echo $this->db->last_query();
			if($query)
			{
				$setter = 1;
			}
			else
			{
				$setter = 0;
			}
			
			$query1=$this->db->update("configurations",array("configValue" => $menutree),array("configTitle" => "menutree"));
			if($query1)
			{
				$setter = 1;
			}
			else
			{
				$setter = 0;
			}
			
			$query2=$this->db->update("configurations",array("configValue" => $smsIntegration),array("configTitle" => "smsIntegration"));
			if($query2)
			{
				$setter = 1;
			}
			else
			{
				$setter = 0;
			}
			
			$query2=$this->db->update("configurations",array("configValue" => $paymentGateway),array("configTitle" => "paymentGateway"));
			if($query2)
			{
				$setter = 1;
			}
			else
			{
				$setter = 0;
			}
		}
		else{
			$query=$this->db->insert("configurations");
			if($query)
			{
				return 1;
			}
			else
			{
				return 0;
			}
		}
	}
	
	public function getConfigurations()
	{
		$query = $this->db->select("*")->from("configurations")->get();
		if($query->num_rows() > 0)
		{
			return $query->result();
		}
		else{
			return array();
		}
	}
	
	public function getSitename()
	{
		$query = $this->db->select("*")->from("configurations")->where(array("configTitle" => "sitename"))->get();
		if($query->num_rows() > 0)
		{
			return $query->result();
		}
		else{
			return array();
		}
	}
	
	public function getMenuTree()
	{
		$query = $this->db->select("*")->from("configurations")->where(array("configTitle" => "menutree"))->get();
		if($query->num_rows() > 0)
		{
			return $query->result();
		}
		else{
			return array();
		}
	}
	
	public function getSMSIntegration()
	{
		$query = $this->db->select("*")->from("configurations")->where(array("configTitle" => "smsIntegration"))->get();
		if($query->num_rows() > 0)
		{
			return $query->result();
		}
		else{
			return array();
		}
	}
	
	public function getPaymentGateway()
	{
		$query = $this->db->select("*")->from("configurations")->where(array("configTitle" => "paymentGateway"))->get();
		if($query->num_rows() > 0)
		{
			return $query->result();
		}
		else{
			return array();
		}
	}
	
}