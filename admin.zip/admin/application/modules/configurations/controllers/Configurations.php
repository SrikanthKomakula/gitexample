<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Configurations extends MX_Controller {
	public function __construct()
	{
		parent::__construct();
		$this->load->model("configurations_model");
	}
	public function index()
	{
		if(@$this->session->userdata("is_logged_in") == 1)
		{
			$data["menu"]="confact";
			$this->load->view('dashboard/header',$data);
			$data["configures"] = $this->configurations_model->getConfigurations();
			$data["sitename"] = $this->configurations_model->getSitename();
			$data["menutree"] = $this->configurations_model->getMenuTree();
			$data["smsIntegration"] = $this->configurations_model->getSMSIntegration();
			$data["paymentGateway"] = $this->configurations_model->getPaymentGateway();
			$this->load->view('index', $data);
			$this->load->view('dashboard/footer');
		}
		else
		{
			redirect(base_url()."index.php/login");
		}
	}
	
	public function saveSettings()
	{
		$sitename = $this->input->post("sitename");
		$menuLevel = $this->input->post("menuLevel");
		$smsapi = $this->input->post("smsapi");
		$businessEmail = $this->input->post("businessEmail");
		$ccavenuePwd = $this->input->post("ccavenuePwd");
		$workingKey = $this->input->post("workingKey");
		$accessKey = $this->input->post("accessKey");
		$paypalBusinessEmail = $this->input->post("paypalBusinessEmail");
		
		$params = array(
			"sitename" => $sitename,
			"menutree" => $menuLevel,
			"smsIntegration" => array(
				"smsapi" => array(
					"apiurl" => $smsapi,
				)
			),
			"paymentGateway" => array(
				"ccavenue" => array(
					"businessEmail" => $businessEmail,
					"password" => $ccavenuePwd,
					"workingkey" => $workingKey,
					"accesskey" => $accessKey
				),
				"paypal" => array(
					"businessEmail" => $paypalBusinessEmail
				)
			),
		);
		$insert = $this->configurations_model->storeConfigurations($params);
		if($insert == 1)
		{
			$this->session->set_userdata(array(
				"success" => "Successfully Saved Data"
			));
			redirect(base_url()."index.php/login");
		}
		else{
			$this->session->set_userdata(array(
				"faile" => "Failed to saved data"
			));
			redirect(base_url()."index.php/configurations");
		}
	}
}
