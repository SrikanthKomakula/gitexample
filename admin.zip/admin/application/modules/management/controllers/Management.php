<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Management extends MX_Controller {
	public function __construct()
	{
		parent::__construct();
		$this->load->model("management_model");
		//$this->load->model("category/category_model");
	}
	public function index()
	{
		if(@$this->session->userdata("is_logged_in") == 1)
		{
			$data["menu"]="management";
			$this->load->view('dashboard/header',$data);
			$data["management"] = $this->management_model->getmanagement();		
			$this->load->view('index', $data);
			$this->load->view('dashboard/footer');
		}
		else
		{
			redirect(base_url()."index.php/login");
		}
	}
	
	public function createmanagement()
	{
		if(@$this->session->userdata("is_logged_in") == 1)
		{
			$data["menu"]="management";
			$this->load->view('dashboard/header',$data);
			$this->load->view('create-item');
			$this->load->view('dashboard/footer');
		}
		else
		{
			redirect(base_url()."index.php/login");
		}
	}
	
	public function savemanagement()
	{
		if($_FILES["thumbImage"]["name"] !='')
		{
			$global=explode(".",$_FILES["thumbImage"]["name"]);
			$thumbImage=time()."1.".end($global);
		}
		else
		{
			$thumbImage="";
		}
		
		if($_FILES["iconImage"]["name"] !='')
		{
			$global=explode(".",$_FILES["iconImage"]["name"]);
			$iconImage=time()."2.".end($global);
		}
		else
		{
			$iconImage="";
		}
		
		if($_FILES["contentImage"]["name"] !='')
		{
			$global=explode(".",$_FILES["contentImage"]["name"]);
			$contentImage=time()."3.".end($global);
		}
		else
		{
			$contentImage="";
		}
		
		$params = array(			
			"title" => $this->input->post("title"),			
			"content" => $this->input->post("content"),			
			"thumb" => $thumbImage,			
			"content_img" => $contentImage,
			"icon" => $iconImage,
			"status" => 1,			
			"date_entered" => @date("Y-m-d H:i:s"),
		);
		$table="management";
		$inaboutt = $this->management_model->storeItems($table,$params);
		if($inaboutt == 1)
		{
			@move_uploaded_file($_FILES["thumbImage"]["tmp_name"],"uploads/managemnt/".$banner_img);
			
				@move_uploaded_file($_FILES["iconImage"]["tmp_name"],"uploads/managemnt/".$iconImage);
				
					@move_uploaded_file($_FILES["contentImage"]["tmp_name"],"uploads/managemnt/".$contentImage);
			$this->session->set_userdata(array(
				"success" => "Successfully Saved Data"
			));
			redirect(base_url()."index.php/management");
		}
		else{
			$this->session->set_userdata(array(
				"faile" => "Failed to save the data"
			));
			redirect(base_url()."index.php/management");
		}
	}
	
	public function savesubmenu()
	{
		$bannerid=$this->input->post("aboutid");			
		
		$params=array(				
			"menu_name" => $this->input->post("menu_name"),			
			"page_type" => 1,				
		);
		//print_r($params);die();
		$table="sub_menu";
		if($bannerid !='')
		{
			$about=$this->process_model->updateItems($table,$params,$bannerid);
		}
		else
		{
			$about=$this->process_model->storeItems($table,$params);
		}
		if($about == 1)
		{
			$this->session->set_userdata(array(
				"success" => "Successfully Data Updated"
			));
			redirect(base_url()."index.php/about");
		}
		else
		{
			$this->session->set_userdata(array(
				"faile" => "Failed to Update data"
			));				
			redirect(base_url()."index.php/about");
		}
	}
	
	public function editmanagement($bannerid)
	{
		if(@$this->session->userdata("is_logged_in") == 1)
		{
			$data["menu"]="management";
			$this->load->view('dashboard/header',$data);
			$data["info"]=$this->management_model->getInfobyId($bannerid);
			$data["bannerid"]=$bannerid;
			
			$this->load->view('edit-item',$data);
			$this->load->view('dashboard/footer');
		}
		else
		{
			redirect(base_url()."index.php/login");
		}
	}
	
	public function updatemanagement()
	{
		if($this->session->userdata("is_logged_in") != 1)
		{
			redirect(base_url()."index.php/login");
		}
		else
		{	
			$bannerid=$this->input->post("managementid");
			
			if(@$_FILES["thumbImage"]["name"] != '')
			{
				$category=explode(".",$_FILES["thumbImage"]["name"]);
				$thumbImage=time()."1.".end($category);
			
				$deleteExistimage=$this->management_model->removeExistsimage1($bannerid);
								
				@move_uploaded_file($_FILES["thumbImage"]["tmp_name"],"uploads/management/".$thumbImage);
						
			}
			else
			{
				$thumbImage=$this->input->post("hiddenmainImage1");
			}
			
			if(@$_FILES["contentImage"]["name"] != '')
			{
				$category=explode(".",$_FILES["contentImage"]["name"]);
				$contentImage=time()."2.".end($category);
			
				$deleteExistimage=$this->management_model->removeExistsimage2($bannerid);
								
				@move_uploaded_file($_FILES["contentImage"]["tmp_name"],"uploads/management/".$contentImage);
						
			}
			else
			{
				$contentImage=$this->input->post("hiddenmainImage2");
			}
			
			
			if(@$_FILES["iconImage"]["name"] != '')
			{
				$category=explode(".",$_FILES["iconImage"]["name"]);
				$iconImage=time()."3.".end($category);
			
				$deleteExistimage=$this->management_model->removeExistsimage3($bannerid);
								
				@move_uploaded_file($_FILES["iconImage"]["tmp_name"],"uploads/management/".$iconImage);
						
			}
			else
			{
				$iconImage=$this->input->post("hiddenmainImage3");
			}
			
			
			$params=array(				
    			"title" => $this->input->post("title"),			
    			"content" => $this->input->post("content"),			
    			"thumb" => $thumbImage,			
    			"content_img" => $contentImage,
    			"icon" => $iconImage,
    			"status" => 1,			
    			"date_entered" => @date("Y-m-d H:i:s"),			
			);
			//print_r($params);die();
			$table="management";
			$management=$this->management_model->updateItems($table,$params,$bannerid);
			if($management == 1)
			{
				$this->session->set_userdata(array(
					"success" => "Successfully Data Updated"
				));
				redirect(base_url()."index.php/management");
			}
			else
			{
				$this->session->set_userdata(array(
					"faile" => "Failed to Update data"
				));				
				redirect(base_url()."index.php/management");
			}
			
		}
	}
	
	public function deleteabout($bannerid)
	{
		//$bannerid=str_replace("_","=",base64_decode($bannerid));		
		$test=$this->process_model->deleteabout($bannerid);
		if($test == 1)
		{
			$this->session->set_userdata(array(
				"success" => "Successfully Deleted"
			));
			redirect(base_url()."index.php/about");
		}
		else
		{
			$this->session->set_userdata(array(
					"faile" => "Failed to Delete data"
				));				
			redirect(base_url()."index.php/about");
		}
		
	}
	
}
