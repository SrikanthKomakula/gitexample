<link href="<?php echo base_url()?>externals/css/plugins/summernote/summernote.css" rel="stylesheet">
<link href="<?php echo base_url()?>externals/css/plugins/summernote/summernote-bs3.css" rel="stylesheet">
	<div class="row wrapper border-bottom white-bg page-heading">	
		<div class="col-sm-4">
			<h2>Edit Description</h2>
			<ol class="breadcrumb">
				<li>
					<a href="<?php echo base_url();?>">Dashboard</a>
				</li>
				<li>
					<a href="<?php echo base_url();?>index.php/management">Management</a>
				</li>
				<li class="active">
					<strong>Edit Description</strong>
				</li>
			</ol>
		</div>
		<div class="col-sm-4 pull-right">
			<h2>
				<a href="<?php echo base_url()?>index.php/management" class="btn btn-w-m btn-default pull-right">Back to List</a>
			</h2>
		</div>
	</div>
	<div class="row">
		<div class="col-lg-12">
			<div class="wrapper wrapper-content">
				<div class="row">
					<div class="col-lg-9">
						<div class="ibox">
							
							<div class="ibox-content">
								
								<form method="POST" action="<?php echo base_url()?>index.php/management/updatemanagement" class="form-horizontal" enctype="multipart/form-data">
								
									<div class="form-group">
										<label class="col-sm-3 control-label">Title</label>
										<div class="col-sm-9">
											<input type="text" name="title" id="title" class="form-control" value="<?php echo @$info[0]->title;?>" required/>
										</div>
									</div>									
									<div class="hr-line-dashed"></div>
																
									<div class="form-group">
										<label class="col-sm-3 control-label">Description</label>
										<div class="col-sm-9">
											<textarea name="content" id="content" class="form-control txtcls" ><?php echo @$info[0]->content;?></textarea>
										</div>
									</div>									
									<div class="hr-line-dashed"></div>
									
									
									
									<div class="form-group">
										<label class="col-sm-3 control-label">Thumbnail</label>
										<div class="col-sm-7">
											<input type="file" accept="image/*" onChange="bhanu()" name="thumbImage" id="thumbImage" class="form-control"/>
											<span id="cond" style="color: red;font-size:13px;">*width and height should be 640 X 440 Px..</span>
										</div>
										<div class="col-sm-2">
											<img src="<?php echo base_url();?>uploads/management/<?php echo @$info[0]->thumb;?>" class="img-responsive" style="width:200px;">
										</div>
									</div>									
									<div class="hr-line-dashed"></div>
									
								
									
									<div class="form-group">
										<label class="col-sm-3 control-label">Content Image</label>
										<div class="col-sm-7">
											<input type="file" accept="image/*" onChange="career()" name="iconImage" id="iconImage" class="form-control"/>
											<span id="cond" style="color: red;font-size:13px;">*width and height should be  90px X 90Px.</span>
										</div>
										<div class="col-sm-2">
											<img src="<?php echo base_url();?>uploads/management/<?php echo @$info[0]->icon;?>" class="img-responsive" style="width:200px;">
										</div>
									</div>									
									<div class="hr-line-dashed"></div>
									
										<div class="form-group">
										<label class="col-sm-3 control-label">Icon</label>
										<div class="col-sm-7">
											<input type="file" accept="image/*" onChange="gro()" name="contentImage" id="contentImage" class="form-control"/>
											<span id="cond" style="color: red;font-size:13px;">*width and height should be 800px X 480 Px.</span>
										</div>
										<div class="col-sm-2">
											<img src="<?php echo base_url();?>uploads/management/<?php echo @$info[0]->content_img;?>" class="img-responsive" style="width:200px;">
										</div>
									</div>									
									<div class="hr-line-dashed"></div>
									
									<div class="form-group">
										<div class="col-sm-4 col-sm-offset-2">
											<!--<button class="btn btn-white" type="reset">Reset</button>-->
											<input type="hidden" name="managementid" id="managementid" value="<?php echo @$bannerid;?>">
											<input type="hidden" name="hiddenmainImage1" id="hiddenmainImage1" value="<?php echo @$info[0]->thumb;?>">
											
											<input type="hidden" name="hiddenmainImage2" id="hiddenmainImage2" value="<?php echo @$info[0]->content_img;?>">
											
											<input type="hidden" name="hiddenmainImage3" id="hiddenmainImage3" value="<?php echo @$info[0]->icon;?>">
											
											<button class="btn btn-primary" type="submit">Save</button>
										</div>
									</div>
								</form>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
 
<script src="<?php echo base_url()?>externals/js/plugins/summernote/summernote.min.js"></script>
  
<script>
$(document).ready(function(){

	$('.txtcls').summernote();

});
var edit = function() {
	$('.click2edit').summernote({focus: true});
};
var save = function() {
	var aHTML = $('.click2edit').code(); //save HTML If you need(aHTML: array).
	$('.click2edit').destroy();
};
function bhanu(){
//alert('fdxsghbdf');
	//Get reference of FileUpload.
	var fileUpload = $("#thumbImage")[0];
	//Check whether HTML5 is supported.
	if (typeof (fileUpload.files) != "undefined") {
		//Initiate the FileReader object.
		var reader = new FileReader();
		//Read the contents of Image File.
		reader.readAsDataURL(fileUpload.files[0]);
		reader.onload = function (e) {
			//Initiate the JavaScript Image object.
			var image = new Image();
			//Set the Base64 string return from FileReader as source.
			image.src = e.target.result;
			image.onload = function () {
				//Determine the Height and Width.
				var height = this.height;
				var width = this.width;
				<!--640*440-->
				   if (height < 436 || height > 444 || width < 635 || width >  645){
					alert("width and height should be 604 X 440 Px.");
					$("#thumbImage").val('');
					return false;
				}
				//alert("Uploaded image has valid Height and Width.");
				return true;
			};
		}
	} else {
		alert("This browser does not support HTML5.");
		return false;
	}
}

function career(){
//alert('fdxsghbdf');
	//Get reference of FileUpload.
	var fileUpload = $("#iconImage")[0];
	//Check whether HTML5 is supported.
	if (typeof (fileUpload.files) != "undefined") {
		//Initiate the FileReader object.
		var reader = new FileReader();
		//Read the contents of Image File.
		reader.readAsDataURL(fileUpload.files[0]);
		reader.onload = function (e) {
			//Initiate the JavaScript Image object.
			var image = new Image();
			//Set the Base64 string return from FileReader as source.
			image.src = e.target.result;
			image.onload = function () {
				//Determine the Height and Width.
				var height = this.height;
				var width = this.width;
				   if (height < 85 || height > 95 || width < 85 || width >  95){
					alert("width and height should be 90 X 90 Px.");
					$("#iconImage").val('');
					return false;
				}
				//alert("Uploaded image has valid Height and Width.");
				return true;
			};
		}
	} else {
		alert("This browser does not support HTML5.");
		return false;
	}
}
/*770*440*/
function gro(){
//alert('fdxsghbdf');
	//Get reference of FileUpload.
	var fileUpload = $("#contentImage")[0];
	//Check whether HTML5 is supported.
	if (typeof (fileUpload.files) != "undefined") {
		//Initiate the FileReader object.
		var reader = new FileReader();
		//Read the contents of Image File.
		reader.readAsDataURL(fileUpload.files[0]);
		reader.onload = function (e) {
			//Initiate the JavaScript Image object.
			var image = new Image();
			//Set the Base64 string return from FileReader as source.
			image.src = e.target.result;
			image.onload = function () {
				//Determine the Height and Width.
				var height = this.height;
				var width = this.width;
				   if (height < 440 || height > 500 || width < 700 || width >  850){
					alert("width and height should be 800 X 480 Px.");
					$("#contentImage").val('');
					return false;
				}
				//alert("Uploaded image has valid Height and Width.");
				return true;
			};
		}
	} else {
		alert("This browser does not support HTML5.");
		return false;
	}
}
</script>