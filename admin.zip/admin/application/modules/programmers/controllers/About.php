<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class About extends MX_Controller {
	public function __construct()
	{
		parent::__construct();
		$this->load->model("about_model");
		//$this->load->model("category/category_model");
	}
	public function index()
	{
		if(@$this->session->userdata("is_logged_in") == 1)
		{
			$data["menu"]="abt";
			$this->load->view('dashboard/header',$data);
			$data["about"] = $this->about_model->getabout();		
			$data["subMenu"] = $this->about_model->getSubmenu();		
			$this->load->view('index', $data);
			$this->load->view('dashboard/footer');
		}
		else
		{
			redirect(base_url()."index.php/login");
		}
	}
	
	public function createabout()
	{
		if(@$this->session->userdata("is_logged_in") == 1)
		{
			$data["menu"]="abt";
			$this->load->view('dashboard/header',$data);
			$this->load->view('create-item');
			$this->load->view('dashboard/footer');
		}
		else
		{
			redirect(base_url()."index.php/login");
		}
	}
	
	public function saveabout()
	{
		if($_FILES["mainImage"]["name"] !='')
		{
			$global=explode(".",$_FILES["mainImage"]["name"]);
			$banner_img=time().".".end($global);
		}
		else
		{
			$banner_img="";
		}
		$params = array(			
			"cms_title" => $this->input->post("cms_title"),			
			"cms_desc" => $this->input->post("cms_desc"),			
			"cms_img" => $banner_img,			
			"page_type" => 1,			
			"created_date" => @date("Y-m-d H:i:s"),
		);
		$table="family_cms";
		$inaboutt = $this->about_model->storeItems($table,$params);
		if($inaboutt == 1)
		{
			@move_uploaded_file($_FILES["mainImage"]["tmp_name"],"uploads/aboutus/".$banner_img);
			$this->session->set_userdata(array(
				"success" => "Successfully Saved Data"
			));
			redirect(base_url()."index.php/about");
		}
		else{
			$this->session->set_userdata(array(
				"faile" => "Failed to save the data"
			));
			redirect(base_url()."index.php/about");
		}
	}
	
	public function savesubmenu()
	{
		$bannerid=$this->input->post("aboutid");			
		
		$params=array(				
			"menu_name" => $this->input->post("menu_name"),			
			"page_type" => 1,				
		);
		//print_r($params);die();
		$table="sub_menu";
		if($bannerid !='')
		{
			$about=$this->about_model->updateItems($table,$params,$bannerid);
		}
		else
		{
			$about=$this->about_model->storeItems($table,$params);
		}
		if($about == 1)
		{
			$this->session->set_userdata(array(
				"success" => "Successfully Data Updated"
			));
			redirect(base_url()."index.php/about");
		}
		else
		{
			$this->session->set_userdata(array(
				"faile" => "Failed to Update data"
			));				
			redirect(base_url()."index.php/about");
		}
	}
	
	public function editabout($bannerid)
	{
		if(@$this->session->userdata("is_logged_in") == 1)
		{
			$data["menu"]="abt";
			$this->load->view('dashboard/header',$data);
			$data["info"]=$this->about_model->getInfobyId($bannerid);
			$data["bannerid"]=$bannerid;
			
			$this->load->view('edit-item',$data);
			$this->load->view('dashboard/footer');
		}
		else
		{
			redirect(base_url()."index.php/login");
		}
	}
	
	public function updateabout()
	{
		if($this->session->userdata("is_logged_in") != 1)
		{
			redirect(base_url()."index.php/login");
		}
		else
		{	
			$bannerid=$this->input->post("aboutid");
			
			if(@$_FILES["mainImage"]["name"] != '')
			{
				$category=explode(".",$_FILES["mainImage"]["name"]);
				$banner_img=time().".".end($category);
			
				$deleteExistimage=$this->about_model->removeExistsimage($bannerid);
								
				@move_uploaded_file($_FILES["mainImage"]["tmp_name"],"uploads/aboutus/".$banner_img);
						
			}
			else
			{
				$banner_img=$this->input->post("hiddenmainImage");
			}
			
			$params=array(				
				"cms_title" => $this->input->post("cms_title"),			
				"cms_desc" => $this->input->post("cms_desc"),			
				"cms_img" => $banner_img,
				"page_type" => 1,				
			);
			//print_r($params);die();
			$table="family_cms";
			$about=$this->about_model->updateItems($table,$params,$bannerid);
			if($about == 1)
			{
				$this->session->set_userdata(array(
					"success" => "Successfully Data Updated"
				));
				redirect(base_url()."index.php/about");
			}
			else
			{
				$this->session->set_userdata(array(
					"faile" => "Failed to Update data"
				));				
				redirect(base_url()."index.php/about");
			}
			
		}
	}
	
	public function deleteabout($bannerid)
	{
		//$bannerid=str_replace("_","=",base64_decode($bannerid));		
		$test=$this->about_model->deleteabout($bannerid);
		if($test == 1)
		{
			$this->session->set_userdata(array(
				"success" => "Successfully Deleted"
			));
			redirect(base_url()."index.php/about");
		}
		else
		{
			$this->session->set_userdata(array(
					"faile" => "Failed to Delete data"
				));				
			redirect(base_url()."index.php/about");
		}
		
	}
	
}
