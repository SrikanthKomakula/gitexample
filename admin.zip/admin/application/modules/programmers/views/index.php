<style>
.center{
	text-align:center;
}
</style>

	<div class="row wrapper border-bottom white-bg page-heading">
		<div class="col-sm-4">
			<h2>About Us</h2>
			<ol class="breadcrumb">
				<li>
					<a href="<?php echo base_url()?>">Dashboard</a>
				</li>
				<li class="active">
					<strong>About Us</strong>
				</li>
			</ol>
		</div>
		<div class="col-sm-4 pull-right">
			<h2>
				<a href="<?php echo base_url()?>index.php/about/createabout" class="btn btn-w-m btn-primary pull-right">Add Description</a>
			</h2>
		</div>
	</div>
	<div class="row">
		<div class="col-lg-12">
			<div class="wrapper wrapper-content">
				<div class="row">
					<div class="ibox">                        
						<div class="ibox-content">
						<?php
						if(@$this->session->userdata("success") != '')
						{
						?>
							<div class="alert alert-success alert-dismissable">
                                <button aria-hidden="true" data-dismiss="alert" class="close" type="button">×</button>
                                <?php
								echo @$this->session->userdata("success");
								@$this->session->unset_userdata("success");
								?>
                            </div>
						<?php
						}
						if(@$this->session->userdata("fail") != '')
						{
						?>
							<div class="alert alert-danger alert-dismissable">
                                <button aria-hidden="true" data-dismiss="alert" class="close" type="button">×</button>
                                <?php
								echo @$this->session->userdata("fail");
								@$this->session->unset_userdata("fail");
								?>
                            </div>
						<?php
						}
						?>
							<div class="row">
								<form method="POST" action="<?php echo base_url()?>index.php/about/savesubmenu" class="form-horizontal" enctype="multipart/form-data">
									<div class="form-group">
										<label class="col-sm-3 control-label">Sub Menu Name</label>
										<div class="col-sm-3">
											<input type="text" name="menu_name" id="menu_name" value="<?php echo @$subMenu[0]->menu_name?>" class="form-control txtcls" required maxlength="15"/>
											<span id="cond" style="color: red;font-size:13px;">*Max Name length 15 characters.</span>
										</div>
										<div class="col-sm-3">
											<input type="hidden" name="aboutid" id="aboutid" value="<?php echo @$subMenu[0]->id?>"/>
											<button class="btn btn-primary" type="submit">Update</button>
										</div>
									</div>									
									<div class="hr-line-dashed"></div>
								</form>
							</div>
							<table class="table table-striped table-bordered table-hover " id="editable" >
								<thead>
									<tr>
										<th class="center">S.No</th>
										<th class="center" style="width:15%;">Title</th>
										<th class="center" style="width:50%;">Description</th>
										<th class="center" style="width:20%;">Image</th>
										<th class="center" style="width:10%;">Actions</th>
									</tr>
								</thead>
								<tbody>
								<?php
								if(@sizeOf($about) > 0)
								{
									for($a=0;$a<@sizeOf($about);$a++)
									{
								?>
									<tr class="gradeX">
										<td class="center">
											<?php echo @($a+1);?>
										</td>
										<td class="center">
											<?php echo @$about[$a]->cms_title;?>
										</td>
										<td class="center">
											<?php echo @$about[$a]->cms_desc;?>
										</td>
										<td class="center">
											<?php
											if(@$about[$a]->cms_img !='')
											{
											?>
											<img style="margin:0 auto;width:100px;" src="<?php echo base_url();?>uploads/aboutus/<?php echo @$about[$a]->cms_img;?>" class="img-responsive">
											<?php
											}else{
												echo "N/A";
											}
											?>
										</td>
										<td class="center">
											<a href="<?php echo base_url()?>index.php/about/editabout/<?php echo @$about[$a]->id;?>"><i class="fa fa-edit"></i></a> 
											<?php
											if($a !=0)
											{
											?>
											&nbsp;|&nbsp;
											<a href="<?php echo base_url()?>index.php/about/deleteabout/<?php echo @$about[$a]->id;?>"><i class="fa fa-trash"></i></a>
											<?php
											}
											?>
										</td>
									</tr>
								<?php
									}
								}
								else
								{
									echo '<tr class="gradeX"><td colspan="5" style="color:red" class="center"><b>No Records Found</b></td></tr>';
								}
								?>
								</tbody>
							</table>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>

	