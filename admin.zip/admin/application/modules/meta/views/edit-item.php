
	<div class="row wrapper border-bottom white-bg page-heading">	
		<div class="col-sm-4">
			<h2>Edit SEO Data</h2>
			<ol class="breadcrumb">
				<li>
					<a href="<?php echo base_url();?>">Dashboard</a>
				</li>
				<li>
					<a href="<?php echo base_url();?>index.php/meta">SEO Data</a>
				</li>
				<li class="active">
					<strong>Edit Data</strong>
				</li>
			</ol>
		</div>
		<div class="col-sm-4 pull-right">
			<h2>
				<a href="<?php echo base_url()?>index.php/meta" class="btn btn-w-m btn-default pull-right">Back to List</a>
			</h2>
		</div>
	</div>
	<div class="row">
		<div class="col-lg-12">
			<div class="wrapper wrapper-content">
				<div class="row">
					<div class="col-lg-9">
						<div class="ibox">
							
							<div class="ibox-content">
								
								<form method="POST" action="<?php echo base_url()?>index.php/meta/updatemeta" class="form-horizontal" enctype="multipart/form-data">
																
									<div class="form-group">
										<label class="col-sm-3 control-label">Page</label>
										<div class="col-sm-9">
											<select name="page_type" id="page_type" class="form-control" required>
												<option>Select Page</option>
												<option <?php if(@$info[0]->page_type == 1){echo "selected='selected'";}?> value="1">Home Page</option>
												<option <?php if(@$info[0]->page_type == 8){echo "selected='selected'";}?> value="8">Testimonials Page</option>
												<option <?php if(@$info[0]->page_type == 2){echo "selected='selected'";}?> value="2">Teachers Page</option>
												<option <?php if(@$info[0]->page_type == 9){echo "selected='selected'";}?> value="9">Venue Page</option>
												<option <?php if(@$info[0]->page_type == 10){echo "selected='selected'";}?> value="10">Programmers Page</option>
											
												<option <?php if(@$info[0]->page_type == 11){echo "selected='selected'";} ?> value="11">ContactUs Page</option>												
											</select>
											
										
										</div>
									</div>									
									<div class="hr-line-dashed"></div>
									<?php
									if(@$info[0]->page_type == 5)
									{
										$bhanu='style="display:block;"';
									}
									else
									{
										$bhanu='style="display:none;"';
									}
									?>
									<div id="services" <?php echo @$bhanu?>>
									<div class="form-group">
										<label class="col-sm-3 control-label">Services</label>
										<div class="col-sm-9">
											<select name="service_id" id="service_id" class="form-control" >
												<option value="">Select Service</option>
												<?php
												if(@sizeOf($services) > 0)
												{
													for($s=1;$s<@sizeOf($services);$s++)
													{
												?>
												<option <?php if(@$info[0]->service_id == @$services[$s]->alias_title){echo "selected='selected'";}?> value="<?php echo @$services[$s]->alias_title;?>"><?php echo @$services[$s]->cms_title;?></option>
												<?php
													}
												}
												?>
											</select>										
										</div>
									</div>									
									<div class="hr-line-dashed"></div>
									</div>
									<?php
									if(@$info[0]->page_type == 7)
									{
										$teja='style="display:block;"';
									}
									else
									{
										$teja='style="display:none;"';
									}
									?>
									<div id="markets" <?php echo @$teja?>>
									<div class="form-group">
										<label class="col-sm-3 control-label">Markets</label>
										<div class="col-sm-9">
											<select name="market_id" id="market_id" class="form-control" >
												<option value="">Select Market</option>
												<?php
												if(@sizeOf($markets) > 0)
												{
													for($m=1;$m<@sizeOf($markets);$m++)
													{
												?>
												<option <?php if(@$info[0]->market_id == @$markets[$m]->alias_title){echo "selected='selected'";}?> value="<?php echo @$markets[$m]->alias_title;?>"><?php echo @$markets[$m]->cms_title;?></option>
												<?php
													}
												}
												?>
											</select>	
										</div>
									</div>									
									<div class="hr-line-dashed"></div>
									</div>
									
									<div class="form-group">
										<label class="col-sm-3 control-label">Meta Title</label>
										<div class="col-sm-9">
											<textarea type="text" name="meta_title" id="meta_title" class="form-control" required><?php echo @$info[0]->meta_title?></textarea>
										</div>
									</div>									
									<div class="hr-line-dashed"></div>
									
									<div class="form-group">
										<label class="col-sm-3 control-label">Meta Keywords</label>
										<div class="col-sm-9">
											<textarea type="text" name="meta_keywords" id="meta_keywords" class="form-control" required><?php echo @$info[0]->meta_keywords?></textarea>
										</div>
									</div>									
									<div class="hr-line-dashed"></div>
									
									<div class="form-group">
										<label class="col-sm-3 control-label">Meta Decsription</label>
										<div class="col-sm-9">
											<textarea type="text" name="meta_desc" id="meta_desc" class="form-control" required><?php echo @$info[0]->meta_desc?></textarea>
										</div>
									</div>									
									<div class="hr-line-dashed"></div>
									
									<div class="form-group">
										<div class="col-sm-4 col-sm-offset-2">
											<!--<button class="btn btn-white" type="reset">Reset</button>-->
											<input type="hidden" name="metaid" id="metaid" value="<?php echo @$bannerid;?>">
											<button class="btn btn-primary" type="submit">Save</button>
										</div>
									</div>
								</form>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
 
<script>
$("#page_type").change(function(){
	var selval=$(this).val();
	if(selval == 5)
	{
		$("#services").css("display","block");
		$("#markets").css("display","none");
		$("#service_id").attr("required",true);
		$("#market_id").removeAttr("required",true);
	}
	else if(selval == 7)
	{
		$("#services").css("display","none");
		$("#markets").css("display","block");
		$("#market_id").attr("required",true);
		$("#service_id").removeAttr("required",true);
	}
	else
	{
		$("#services").css("display","none");
		$("#markets").css("display","none");
		$("#market_id").removeAttr("required",true);
		$("#service_id").removeAttr("required",true);
	}
});
</script>