<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Meta extends MX_Controller {
	public function __construct()
	{
		parent::__construct();
		$this->load->model("meta_model");
		//$this->load->model("category/category_model");
	}
	public function index()
	{
		if(@$this->session->userdata("is_logged_in") == 1)
		{
			$data["menu"]="meta";
			$this->load->view('dashboard/header',$data);
			$data["meta"] = $this->meta_model->getmeta();		
			$this->load->view('index', $data);
			$this->load->view('dashboard/footer');
		}
		else
		{
			redirect(base_url()."index.php/login");
		}
	}
	
	public function createmeta()
	{
		if(@$this->session->userdata("is_logged_in") == 1)
		{
			$data["menu"]="meta";
			$this->load->view('dashboard/header',$data);
			$data['services']=$this->meta_model->getAllServices(5);
			$data['markets']=$this->meta_model->getAllServices(4);
			$this->load->view('create-item',$data);
			$this->load->view('dashboard/footer');
		}
		else
		{
			redirect(base_url()."index.php/login");
		}
	}
	
	public function savemeta()
	{
		$params = array(			
			"service_id" => $this->input->post("service_id"),										
			"market_id" => $this->input->post("market_id"),										
			"meta_title" => $this->input->post("meta_title"),										
			"meta_keywords" => $this->input->post("meta_keywords"),										
			"meta_desc" => $this->input->post("meta_desc"),										
			"page_type" => $this->input->post("page_type"),										
			"created_date" => @date("Y-m-d H:i:s"),
		);
		$table="meta_data";
		$inmetat = $this->meta_model->storeItems($table,$params);
		if($inmetat == 1)
		{
			//@move_uploaded_file($_FILES["mainImage"]["tmp_name"],"uploads/careers/".$banner_img);
			$this->session->set_userdata(array(
				"success" => "Successfully Saved Data"
			));
			redirect(base_url()."index.php/meta");
		}
		else{
			$this->session->set_userdata(array(
				"faile" => "Failed to save the data"
			));
			redirect(base_url()."index.php/meta");
		}
	}
	
	public function editmeta($bannerid)
	{
		if(@$this->session->userdata("is_logged_in") == 1)
		{
			$data["menu"]="meta";
			$this->load->view('dashboard/header',$data);
			$data["info"]=$this->meta_model->getInfobyId($bannerid);
			$data["bannerid"]=$bannerid;
			$data['services']=$this->meta_model->getAllServices(5);
			$data['markets']=$this->meta_model->getAllServices(4);
			$this->load->view('edit-item',$data);
			$this->load->view('dashboard/footer');
		}
		else
		{
			redirect(base_url()."index.php/login");
		}
	}
	
	public function updatemeta()
	{
		if($this->session->userdata("is_logged_in") != 1)
		{
			redirect(base_url()."index.php/login");
		}
		else
		{	
			$bannerid=$this->input->post("metaid");
			
			$params = array(			
				"service_id" => $this->input->post("service_id"),										
				"market_id" => $this->input->post("market_id"),										
				"meta_title" => $this->input->post("meta_title"),										
				"meta_keywords" => $this->input->post("meta_keywords"),										
				"meta_desc" => $this->input->post("meta_desc"),										
				//"page_type" => $this->input->post("page_type"),										
				"created_date" => @date("Y-m-d H:i:s"),
			);
			$table="meta_data";
			$meta=$this->meta_model->updateItems($table,$params,$bannerid);
			if($meta == 1)
			{
				$this->session->set_userdata(array(
					"success" => "Successfully Data Updated"
				));
				redirect(base_url()."index.php/meta");
			}
			else
			{
				$this->session->set_userdata(array(
					"faile" => "Failed to Update data"
				));				
				redirect(base_url()."index.php/meta");
			}
			
		}
	}
	
	public function deletemeta($bannerid)
	{
		//$bannerid=str_replace("_","=",base64_decode($bannerid));		
		$test=$this->meta_model->deletemeta($bannerid);
		if($test == 1)
		{
			$this->session->set_userdata(array(
				"success" => "Successfully Deleted"
			));
			redirect(base_url()."index.php/meta");
		}
		else
		{
			$this->session->set_userdata(array(
					"faile" => "Failed to Delete data"
				));				
			redirect(base_url()."index.php/meta");
		}
		
	}	
}
