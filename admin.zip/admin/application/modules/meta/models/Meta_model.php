<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Meta_model extends CI_Model {

	
	public function getmeta()
	{
		$this->db->select("*")->from("meta_data");		
		$query=$this->db->get();
		if($query->num_rows() > 0)
		{
			return $query->result();
		}
		else{
			return array();
		}
	}
	
	public function getAllServices($type)
	{
		$this->db->select("*")->from("family_cms")->where(array("page_type" => $type));		
		$query=$this->db->get();
		if($query->num_rows() > 0)
		{
			return $query->result();
		}
		else{
			return array();
		}
	}
	
	public function storeItems($table,$params)
	{
		$query=$this->db->insert($table,$params);
		if($query)
		{
			return 1;
		}
		else{
			return 0;
		}
	}
	
	public function updateItems($table,$params,$bannerid)
	{
		$query=$this->db->update($table,$params,array("id" => $bannerid));
		if($query)
		{
			return 1;
		}
		else{
			return 0;
		}
	}
	
	public function getInfobyId($bannerid)
	{
		$query = $this->db->select("*")->from("meta_data")->where("id",$bannerid)->get();
		if($query->num_rows() > 0)
		{
			return $query->result();
		}
		else{
			return array();
		}
	}
	
	public function deletemeta($bannerid)
	{		
		$deletequery=$this->db->delete("meta_data",array("id" => $bannerid));
		if($deletequery)
		{
			return 1;
		}
		else
		{
			return 0;
		}
	}
}