<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Visit_cust extends MX_Controller {
	public function __construct()
	{
		parent::__construct();
		$this->load->model("visit_cust_model");
		//$this->load->model("category/category_model");
	}
	public function index()
	{
		if(@$this->session->userdata("is_logged_in") == 1)
		{
			$data["menu"]="visit_cust";
			$this->load->view('dashboard/header',$data);
			$data["visit_cust"] = $this->visit_cust_model->getvisit_cust();
			
			$this->load->view('index', $data);
			$this->load->view('dashboard/footer');
		}
		else
		{
			redirect(base_url()."index.php/login");
		}
	}

	
	
	public function edit_visit_cust($bannerid)
	{
		if(@$this->session->userdata("is_logged_in") == 1)
		{
			$data["menu"]="visit_cust";
			$this->load->view('dashboard/header',$data);
			$data["info"]=$this->visit_cust_model->getInfobyId($bannerid);
			$data["bannerid"]=$bannerid;
			
			$this->load->view('edit-item',$data);
			$this->load->view('dashboard/footer');
		}
		else
		{
			redirect(base_url()."index.php/login");
		}
	}
	
	public function updatevisit_cust()
	{
		if($this->session->userdata("is_logged_in") != 1)
		{
			redirect(base_url()."index.php/login");
		}
		else
		{	
			$bannerid=$this->input->post("visitid");
			
			
			$params=array(				
				"user_id" => $this->input->post("user_id"),			
				"t_date" => $this->input->post("t_date"),			
				"t_time" => $this->input->post("t_time"),	
				"t_name" => $this->input->post("t_name"),	
				"feedback" => $this->input->post("feedback"),	
				"interested" => $this->input->post("interested"),	
			);
			//print_r($params);die();
			$table="schedule_tour";
			$teachers=$this->visit_cust_model->updateItems($table,$params,$bannerid);
			if($teachers == 1)
			{
				$this->session->set_userdata(array(
					"success" => "Successfully Data Updated"
				));
				redirect(base_url()."index.php/visit_cust");
			}
			else
			{
				$this->session->set_userdata(array(
					"faile" => "Failed to Update data"
				));				
				redirect(base_url()."index.php/visit_cust");
			}
			
		}
	}
	
	public function delete_visit_cust($bannerid)
	{
		$test=$this->visit_cust_model->deletevisit_cust($bannerid);
		if($test == 1)
		{
			$this->session->set_userdata(array(
				"success" => "Successfully Deleted"
			));
			redirect(base_url()."index.php/visit_cust");
		}
		else
		{
			$this->session->set_userdata(array(
					"faile" => "Failed to Delete data"
				));				
			redirect(base_url()."index.php/visit_cust");
		}
		
	}
	
	
}
