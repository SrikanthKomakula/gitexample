<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Properties_model extends CI_Model {
    
    
    
    
    
    function __construct() { 
        // Set table name 
        $this->table = 'customers'; 
        $this->imgTbl = 'property_images';
         $this->galleryTbl   = 'properties'; 
    } 
    
		public function getproperties()
	{
	    
	    $this->db->select('properties.*, customers.*, properties.id as prop_id');
        $this->db->from('properties');
        $this->db->join('customers', 'customers.id = properties.user_id', 'inner');
        $query = $this->db->get();
		if($query->num_rows() > 0)
		{
			return $query->result();
		}
		else{
			return array();
		}
	}
	
	
	
	
		public function getbuy_quote_by_id($id)
	{
	    
	    $this->db->select('*');
        $this->db->from('buy_form');
        	$this->db->where(array("id" => $id));	
        $query = $this->db->get();
		if($query->num_rows() > 0)
		{
			return $query->result_array();
		}
		else{
			return array();
		}
	}
	
		public function getbuy_quote()
	{
	    
	    $this->db->select('buy_form.*, customers.*, buy_form.id as prop_id');
        $this->db->from('buy_form');
        $this->db->join('customers', 'customers.id = buy_form.user_id', 'inner');
        $query = $this->db->get();
		if($query->num_rows() > 0)
		{
			return $query->result();
		}
		else{
			return array();
		}
	}
	
	public function getSubmenu()
	{
		$this->db->select("*")->from("sub_menu")->where(array("page_type" => 1));		
		$query=$this->db->get();
		if($query->num_rows() > 0)
		{
			return $query->result();
		}
		else{
			return array();
		}
	}
	
	public function storeItems($table,$params)
	{
		$query=$this->db->insert($table,$params);
		if($query)
		{
			return 1;
		}
		else{
			return 0;
		}
	}
	
	public function updateItems($table,$params,$bannerid)
	{
		$query=$this->db->update($table,$params,array("id" => $bannerid));
		if($query)
		{
			return 1;
		}
		else{
			return 0;
		}
	}
	
	public function getInfobyId($bannerid)
	{
		$query = $this->db->select("*")->from("process")->where("id",$bannerid)->get();
		if($query->num_rows() > 0)
		{
			return $query->result();
		}
		else{
			return array();
		}
	}
	
	public function deleteprperty($bannerid)
	{		
		$this->db->select("*")->from("properties")->where(array("id" => $bannerid));		
		$query=$this->db->get();
		
		if($query->num_rows() == 1)
		{
			$result=$query->result();
			@unlink(FCPATH . 'uploads/aboutus/' . $result[0]->cms_img);					
		}
		$deletequery=$this->db->delete("family_cms",array("id" => $bannerid));
		if($deletequery)
		{
			return 1;
		}
		else
		{
			return 0;
		}
	}
	
	public function removeExistsimage($bannerid)
	{
		$this->db->select("*")->from("process")->where(array("id" => $bannerid));
		$query=$this->db->get();
		//echo $this->db->last_query();die();
		if($query->num_rows() > 0)
		{
			$result=$query->result();		
			$delete=@unlink(FCPATH . 'uploads/process/' . $result[0]->icon);
			if($delete)
			{
				return 1;
			}
			else
			{
				return 0;
			}
		}
	}
	
	
	 public function getPropertybyID($id = ''){ 
        $this->db->select("*, (SELECT file_name FROM ".$this->imgTbl." WHERE property_id = ".$this->galleryTbl.".id ORDER BY id DESC LIMIT 1) as default_image"); 
        $this->db->from($this->galleryTbl); 
        if($id){ 
            $this->db->where('id', $id); 
            $query  = $this->db->get(); 
            $result = ($query->num_rows() > 0)?$query->row_array():array(); 
             
            if(!empty($result)){ 
                $this->db->select('*'); 
                $this->db->from($this->imgTbl); 
                $this->db->where('property_id', $result['id']); 
                $this->db->order_by('id', 'desc'); 
                $query  = $this->db->get(); 
                $result2 = ($query->num_rows() > 0)?$query->result_array():array(); 
                $result['images'] = $result2;  
                
                
            }  
        }else{ 
            $this->db->order_by('id', 'desc'); 
            $query  = $this->db->get(); 
            $result = ($query->num_rows() > 0)?$query->result_array():array(); 
        } 
         
        // return fetched data 
        return !empty($result)?$result:false; 
    } 
    
     /*Delete property row*/
     public function delete($id){ 
        // Delete gallery data 
        $delete = $this->db->delete($this->galleryTbl, array('id' => $id)); 
         
        // Return the status 
        return $delete?true:false; 
    } 
    
    
      /*Delete Buy Quote*/
     public function deletebuy_quote($id){ 
        // Delete gallery data 
        $delete = $this->db->delete('buy_form', array('id' => $id)); 
         
        // Return the status 
        return $delete?true:false; 
    } 
    
     /* 
     * Delete image data from the database 
     * @param array filter data based on the passed parameter 
     */ 
    public function deleteImage($con){ 
        // Delete image data 
        $delete = $this->db->delete($this->imgTbl, $con); 
         
        // Return the status 
        return $delete?true:false; 
    } 
    
    
    /* 
     * Update gallery data into the database 
     * @param $data array to be update based on the passed parameters 
     * @param $id num filter data 
     */ 
    public function update($data, $id) { 
        if(!empty($data) && !empty($id)){ 
            // Add modified date if not included 
            if(!array_key_exists("modified", $data)){ 
                $data['modified'] = date("Y-m-d H:i:s"); 
            } 
             
            // Update gallery data 
            $update = $this->db->update($this->galleryTbl, $data, array('id' => $id)); 
            
            
            // Return the status 
            return $update?true:false; 
        } 
        return false; 
    } 
    
	
}