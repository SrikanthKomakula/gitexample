<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Properties extends MX_Controller {
	public function __construct()
	{
		parent::__construct();
		$this->load->model("properties_model");
		//$this->load->model("category/category_model");
	}
	public function index()
	{
		if(@$this->session->userdata("is_logged_in") == 1)
		{
			$data["menu"]="properties";
			$this->load->view('dashboard/header',$data);
			$data["properties"] = $this->properties_model->getproperties();		
			$this->load->view('index', $data);
			$this->load->view('dashboard/footer');
		}
		else
		{
			redirect(base_url()."index.php/login");
		}
	}

/*Buy form quote*/
	public function buy_quote()
	{
		if(@$this->session->userdata("is_logged_in") == 1)
		{
			$data["menu"]="buy_quote";
			$this->load->view('dashboard/header',$data);
			$data["buy_quote"] = $this->properties_model->getbuy_quote();		
			$this->load->view('buy_quote', $data);
			$this->load->view('dashboard/footer');
		}
		else
		{
			redirect(base_url()."index.php/login");
		}
	}
	
		public function edit_property($id)
	{
			if(@$this->session->userdata("is_logged_in") == 1)
		{
		    $bannerid=1;
			$data["menu"]="properties";
			$this->load->view('dashboard/header',$data);
			$data["properties"]=$this->properties_model->getPropertybyID($id);
			$data["bannerid"]=$bannerid;
			$this->load->view('edit-item',$data);
			$this->load->view('dashboard/footer');
		}
		else
		{
			redirect(base_url()."index.php/login");
		}
	}
	
	
	 
    
     public function updateproperties(){ 
         $id= $this->input->post("property_id");
        $data = $galleryData = array(); 
        
        // Get gallery data 
        $galleryData = $this->properties_model->getPropertybyID($id); 
       // print_r($galleryData);exit;
        // If update request is submitted 
            // Form field validation rules 
         
        $data = $galleryData = array(); 
        $errorUpload = ''; 
         
            
          if($this->input->post("property_status") == ""){
              $property_status = "sale";
             
          }else{
              $property_status = $this->input->post("property_status");
          }
            
            // Prepare gallery data 
            $galleryData = array( 
            "property_type" => $this->input->post("property_type"),			
			"property_name" => $this->input->post("property_name"),	
			"property_status" => $property_status,
			"area_units" => $this->input->post("area_units"),
			"area_value" => $this->input->post("area_value"),
			"squards_house" => $this->input->post("squards_house"),
			"sqft_house" => $this->input->post("sqft_house"),
			"rental_period" => $this->input->post("rental_period"),	
			"rental_income_avg" => $this->input->post("rental_income_avg"),	
			"price_per_unit" => $this->input->post("price_per_unit"),
			"amenities" => $this->input->post("amenities"),
			"property_price" => $this->input->post("property_price"),
			"friendly_addr" => $this->input->post("friendly_addr"),	
			"place" => $this->input->post("place"),
			"district" => $this->input->post("district"),
			"state" => $this->input->post("state"),
			"dimensions" => $this->input->post("dimensions"),	
			"facing" => $this->input->post("facing"),	
			"bedrooms" => $this->input->post("bedrooms"),
			"bed_room_size_1" => $this->input->post("bed_room_size_1"),
			"bed_room_size_2" => $this->input->post("bed_room_size_2"),
			"bed_room_size_3" => $this->input->post("bed_room_size_3"),
			"bed_room_size_4" => $this->input->post("bed_room_size_4"),
			"bathrooms" => $this->input->post("bathrooms"),
			"balcony" => $this->input->post("balcony"),
			"parking" => $this->input->post("parking"),
			"car_coverd" => $this->input->post("car_coverd"),
			"gst_charges" => $this->input->post("gst_charges"),
			"approved_by" => $this->input->post("approved_by"),
			"position_of_flat" => $this->input->post("position_of_flat"),
			"time_to_handover" => $this->input->post("time_to_handover"),
			"description" => $this->input->post("description"),
			"status" => 1,
			"created" => @date("Y-m-d H:i:s"),
            ); 
            
           // print_r($galleryData);exit;
            
                // Update gallery data 
                $update = $this->properties_model->update($galleryData, $id); 
                    $galleryID = $update;  
                  if($update){ 
			
			$this->session->set_userdata(array(
				"success" => "Successfully Saved Data"
			));
			
				redirect(base_url()."index.php/properties");
                }else{ 
                   $this->session->set_userdata(array(
				"faile" => "Failed to save the data"
			));
			redirect(base_url()."index.php/properties");
                } 
         
    }
	
	

	

	 public function deleteproperties($id){ 
        // Check whether id is not empty 
        if($id){ 
            $galleryData = $this->properties_model->getPropertybyID($id); 
             //print_r($galleryData);exit;
            // Delete gallery data 
            $delete = $this->properties_model->delete($id); 
             
            if($delete){ 
                // Delete images data  
                $condition = array('property_id' => $id);  
                $deleteImg = $this->properties_model->deleteImage($condition); 
                  
                  /*Deleting thumbnail*/
                  @unlink('uploads/properties/'.$galleryData['thumbnail']);
                  
                // Remove files from the server  
                if(!empty($galleryData['images'])){  
                    foreach($galleryData['images'] as $img){  
                        @unlink('uploads/properties/'.$img['file_name']);  
                    }  
                }
                
                 
                $this->session->set_userdata(array(
				"success" => "Successfully Deleted"
			));
            }else{ 
                	$this->session->set_userdata(array(
					"faile" => "Failed to Delete data"
				));	
            } 
        } 
 
        redirect(base_url()."index.php/users"); 
    } 
    
	

	 public function deletebuy_quote($id){ 
        // Check whether id is not empty 
        if($id){ 
            $galleryData = $this->properties_model->getbuy_quote_by_id($id); 
             //print_r($galleryData);exit;
            // Delete gallery data 
            $delete = $this->properties_model->deletebuy_quote($id); 
             
            if($delete){ 
                  /*Deleting thumbnail*/
                  @unlink('uploads/properties/'.$galleryData['thumbnail']);
                 
                $this->session->set_userdata(array(
				"success" => "Successfully Deleted"
			));
            }else{ 
                	$this->session->set_userdata(array(
					"faile" => "Failed to Delete data"
				));	
            } 
        } 
 
        redirect(base_url()."index.php/properties/buy_quote"); 
    } 
    
	
}
