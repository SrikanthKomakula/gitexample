<link href="<?php echo base_url()?>externals/css/plugins/summernote/summernote.css" rel="stylesheet">
<link href="<?php echo base_url()?>externals/css/plugins/summernote/summernote-bs3.css" rel="stylesheet">
	<div class="row wrapper border-bottom white-bg page-heading">	
		<div class="col-sm-4">
			<h2>Edit Description</h2>
			<ol class="breadcrumb">
				<li>
					<a href="<?php echo base_url();?>">Dashboard</a>
				</li>
				<li>
					<a href="<?php echo base_url();?>index.php/process">Process</a>
				</li>
				<li class="active">
					<strong>Edit Description</strong>
				</li>
			</ol>
		</div>
		<div class="col-sm-4 pull-right">
			<h2>
				<a href="<?php echo base_url()?>index.php/properties" class="btn btn-w-m btn-default pull-right">Back to List</a>
			</h2>
		</div>
	</div>
	<div class="row">
		<div class="col-lg-12">
			<div class="wrapper wrapper-content">
				<div class="row">
					<div class="col-lg-9">
						<div class="ibox">
							
							<div class="ibox-content">
								
								<form method="POST" action="<?php echo base_url()?>index.php/properties/updateproperties" class="form-horizontal" enctype="multipart/form-data">
								
								    <div class="form-group">
										<label class="col-sm-3 control-label">Property Type</label>
										<div class="col-sm-9">
										    
										    <select class="form-control basic-select" name="property_type" id="property_type" required>
                                                <option value="">Property Type</option>
                                                <option value="plot"  <?php echo ($properties['property_type']=='plot')?'selected':''; ?>>PLOT</option>
                                                <option value="flat" <?php echo ($properties['property_type']=='flat')?'selected':''; ?>>FLAT</option>
                                                <option value="independent_duplex" <?php echo ($properties['property_type']=='independent_duplex')?'selected':''; ?>>INDEPENDENTHOUSE OR DUPLEX HOUSE</option>
                                                <option value="commercial_office" <?php echo ($properties['property_type']=='commercial_office')?'selected':''; ?>>COMMERCIAL SPACE OR OFFICE SPACE</option>
                                                <option value="rental_lease" <?php echo ($properties['property_type']=='rental_lease')?'selected':''; ?>>RENTAL OT LEASE</option>
                                                <option value="agriculture_lands" <?php echo ($properties['property_type']=='agriculture_lands')?'selected':''; ?>>AGRICULTURE LANDS </option>
                                              </select>
										   
										</div>
									</div>									
																
								
									<div class="form-group">
										<label class="col-sm-3 control-label">Property Name</label>
										<div class="col-sm-9">
											<input type="text" class="form-control" placeholder="Property Name" name="property_name" value="<?php echo $properties['property_name']; ?>"  required>
										</div>
									</div>									
										
										
										
									<div class="form-group" id="property_status_div">
										<label class="col-sm-3 control-label">Property Status</label>
										<div class="col-sm-9">
											<select class="form-control basic-select" name="property_status" id="property_status" required>
                                          <option value="">Select Status</option>
                                        <option value="sale"  <?php echo ($properties['property_status']=='sale')?'selected':''; ?>>For sale</option>
                                        <option value="rent"  <?php echo ($properties['property_status']=='rent')?'selected':''; ?>>For rent</option>
                                      </select>
										</div>
									</div>									
									
									
									<div class="form-group"  id="area_units_div">
										<label class="col-sm-3 control-label">Select Area Units</label>
										<div class="col-sm-9">
											<select class="form-control basic-select" name="area_units" id="area_units" required>
                                              <option value="">Select Area Units</option>
                                            <option value="sqft"  <?php echo ($properties['area_units']=='sqft')?'selected':''; ?>>Sq ft</option>
                                            <option value="squards"  <?php echo ($properties['area_units']=='squards')?'selected':''; ?>>Squards</option>
                                            <option value="acres"  <?php echo ($properties['area_units']=='acres')?'selected':''; ?>>Acres</option>
                                          </select>
										</div>
									</div>									
									
									<div class="form-group"   id="area_value_div">
										<label class="col-sm-3 control-label">How Many Squards / Sq ft / Acres?</label>
										<div class="col-sm-9">
											<input class="form-control" placeholder="value" name="area_value" id="area_value" value="<?php echo $properties['area_value']; ?>" onkeypress="return event.charCode >= 48 &amp;&amp; event.charCode <= 57" required>
										</div>
									</div>									
										
										
										<div class="form-group"  id="squards_house_div">
										<label class="col-sm-3 control-label">How Many Squards?</label>
										<div class="col-sm-9">
											<input class="form-control" placeholder="Squards" name="squards_house" id="squards_house" onkeypress="return event.charCode >= 48 &amp;&amp; event.charCode <= 57"  value="<?php echo $properties['squards_house']; ?>"  required>
										</div>
									</div>									
										
										<div class="form-group" id="sqft_house_div">
										<label class="col-sm-3 control-label">How Many Sq ft?</label>
										<div class="col-sm-9">
											<input class="form-control" placeholder="Sq ft" name="sqft_house" id="sqft_house" onkeypress="return event.charCode >= 48 &amp;&amp; event.charCode <= 57"  value="<?php echo $properties['sqft_house']; ?>"  required>
										</div>
									</div>									
										
									<div class="form-group"  id="rental_period_div">
										<label class="col-sm-3 control-label">Rental Period</label>
										<div class="col-sm-9">
											<select class="form-control basic-select" id="rental_period" name="rental_period" required>
                          <option value="">Select Rental Period</option>
                        <option value="monthly" <?php echo ($properties['rental_period']=='monthly')?'selected':''; ?>>Monthly</option>
                        <option value="yearly" <?php echo ($properties['rental_period']=='yearly')?'selected':''; ?>>yearly</option>
                        </select>
										</div>
									</div>									
											
											
											<div class="form-group">
										<label class="col-sm-3 control-label">Property price Per Unit</label>
										<div class="col-sm-9">
											<input type="text" class="form-control" id="price_per_unit" name="price_per_unit" onkeypress="return event.charCode >= 48 &amp;&amp; event.charCode <= 57" placeholder="Property price Per Unit" value="<?php echo $properties['price_per_unit']; ?>" required>
										</div>
									</div>	
									
									<div class="form-group">
										<label class="col-sm-3 control-label">Amenities</label>
										<div class="col-sm-9">
											<input type="text" class="form-control" id="amenities" name="amenities"  value="<?php echo $properties['amenities']; ?>"  onkeypress="return event.charCode >= 48 &amp;&amp; event.charCode <= 57" placeholder="Amenities">
										</div>
									</div>	
										
										
										
											<div class="form-group">
										<label class="col-sm-3 control-label">Property price</label>
										<div class="col-sm-9">
											<input type="text" class="form-control" id="property_price" name="property_price" placeholder="Total Amount" onkeypress="return event.charCode >= 48 &amp;&amp; event.charCode <= 57" value="<?php echo $properties['property_price']; ?>" readonly>
										</div>
									</div>									
										
										
									
											<div class="form-group">
										<label class="col-sm-3 control-label">Rental Income Average </label>
										<div class="col-sm-9">
											<input type="text" class="form-control" id="rental_income_avg" name="rental_income_avg" placeholder="Total Amount" value="<?php echo $properties['rental_income_avg']; ?>" onkeypress="return event.charCode >= 48 &amp;&amp; event.charCode <= 57" required>
										</div>
									</div>									
												
												<div class="form-group">
										<label class="col-sm-3 control-label">Rental Income Average </label>
										<div class="col-sm-9">
											<input type="text" class="form-control" id="rental_income_avg" name="rental_income_avg" placeholder="Total Amount" value="<?php echo $properties['rental_income_avg']; ?>" onkeypress="return event.charCode >= 48 &amp;&amp; event.charCode <= 57" required>
										</div>
									</div>									
												
																
									<div class="form-group">
										<label class="col-sm-3 control-label">Property Address</label>
										<div class="col-sm-9">
											<input type="text" class="form-control" id="autocomplete1" name="friendly_addr" placeholder="Enter Address"  value="<?php echo $properties['friendly_addr']; ?>" required>
										</div>
									</div>									
												
									<div class="form-group">
										<label class="col-sm-3 control-label">Place</label>
										<div class="col-sm-9">
											<input type="text" class="form-control" id="place" name="place" placeholder="Enter Place" value="<?php echo $properties['place']; ?>" required>
										</div>
									</div>									
															
												
									<div class="form-group">
										<label class="col-sm-3 control-label">District</label>
										<div class="col-sm-9">
											 <input type="text" class="form-control" name="district" id="district" placeholder="Enter District" value="<?php echo $properties['district']; ?>" required>
										</div>
									</div>									
															
									
										<div class="form-group">
										<label class="col-sm-3 control-label">State</label>
										<div class="col-sm-9">
											 <select class="form-control basic-select" name="state" id="state" required>
                        <option value="telangana" <?php echo ($properties['state']=='telangana')?'selected':''; ?>>Telangana</option>
                        <option value="andrapradesh"  <?php echo ($properties['state']=='andrapradesh')?'selected':''; ?>>Andrapradesh</option>
                        <option value="Tamilnadu"  <?php echo ($properties['state']=='Tamilnadu')?'selected':''; ?>>Tamilnadu</option>
                        <option value="Karnataka"  <?php echo ($properties['state']=='Karnataka')?'selected':''; ?>>Karnataka</option>
                        <option value="Goa"  <?php echo ($properties['state']=='Goa')?'selected':''; ?>>Goa</option>
                        <option value="Maharashtra"  <?php echo ($properties['state']=='Maharashtra')?'selected':''; ?>>Maharashtra</option>
                        <option value="Delhi"  <?php echo ($properties['state']=='Delhi')?'selected':''; ?>>Delhi</option>
                        <option value="Noida"  <?php echo ($properties['state']=='Noida')?'selected':''; ?>>Noida</option>
                      </select>
										</div>
									</div>									
															
																
										<div class="form-group"  id="dimensions_div">
										<label class="col-sm-3 control-label">Dimensions</label>
										<div class="col-sm-9">
											 <input type="text" class="form-control" placeholder="Dimensions" name="dimensions" id="dimensions"  value="<?php echo $properties['dimensions']; ?>"  required>
										</div>
									</div>									
									
									<div class="form-group"  id="facing_div">
										<label class="col-sm-3 control-label">Facing</label>
										<div class="col-sm-9">
											  <select class="form-control basic-select" name="facing" id="facing" required>
                         <option value="">Select Facing</option>
                        <option value="EAST"  <?php echo ($properties['facing']=='EAST')?'selected':''; ?>>EAST</option>
                        <option value="WEST"  <?php echo ($properties['facing']=='WEST')?'selected':''; ?>>WEST</option>
                        <option value="NORTH"  <?php echo ($properties['facing']=='NORTH')?'selected':''; ?>>NORTH</option>
                        <option value="SOUTH"  <?php echo ($properties['facing']=='SOUTH')?'selected':''; ?>>SOUTH</option>
                        <option value="NORTH EAST"  <?php echo ($properties['facing']=='NORTH EAST')?'selected':''; ?>>NORTH EAST</option>
                        <option value="SOUTH EAST"  <?php echo ($properties['facing']=='SOUTH EAST')?'selected':''; ?>>SOUTH EAST</option>
                        <option value="NORTH WEST"  <?php echo ($properties['facing']=='NORTH WEST')?'selected':''; ?>>NORTH WEST</option>
                        <option value="SOUTH WEST"  <?php echo ($properties['facing']=='SOUTH WEST')?'selected':''; ?>>SOUTH WEST</option>
                      </select>
										</div>
									</div>									
															
									<div class="form-group" id="bedrooms_div">
										<label class="col-sm-3 control-label">Bedrooms</label>
										<div class="col-sm-9">
											 <select class="form-control basic-select" id="bedrooms" name="bedrooms" required>
                                         <option value="">Select Bedrooms</option>
                                        <option value="1"  <?php echo ($properties['bedrooms']=='1')?'selected':''; ?>>1</option>
                                        <option value="2" <?php echo ($properties['bedrooms']=='2')?'selected':''; ?>>2</option>
                                        <option value="3" <?php echo ($properties['bedrooms']=='3')?'selected':''; ?>>3</option>
                                        <option value="4" <?php echo ($properties['bedrooms']=='4')?'selected':''; ?>>4</option>
                                      </select>
										</div>
									</div>									
											
									<div class="form-group"  id="bedroom_size_div">
										<label class="col-sm-3 control-label">Bedroom Sizes</label>
										<div class="col-sm-9">
											 <div class="row">
                          <div class="col-sm-3">
                              <input type="text" class="form-control" placeholder="Bedroom 1" name="bed_room_size_1" id="bed_room_sizes">
                          </div>
                          <div class="col-sm-3">
                              <input type="text" class="form-control" placeholder="Bedroom 2" name="bed_room_size_2" id="bed_room_sizes">
                          </div>
                          <div class="col-sm-3">
                              <input type="text" class="form-control" placeholder="Bedroom 3" name="bed_room_size_3" id="bed_room_sizes">
                          </div>
                          
                        <div class="col-sm-3">
                              <input type="text" class="form-control" placeholder="Bedroom 4" name="bed_room_size_4" id="bed_room_sizes">
                          </div>
                      </div>
                      
										</div>
									</div>									
									<div class="form-group"  id="bathrooms_div">
										<label class="col-sm-3 control-label">Bathrooms</label>
										<div class="col-sm-9">
											 <select class="form-control basic-select" id="bathrooms" name="bathrooms" required>
                        <option value="">Select Bathrooms</option>
                        <option value="1" <?php echo ($properties['bathrooms']=='1')?'selected':''; ?>>1</option>
                        <option value="2" <?php echo ($properties['bathrooms']=='2')?'selected':''; ?>>2</option>
                        <option value="3" <?php echo ($properties['bathrooms']=='3')?'selected':''; ?>>3</option>
                        <option value="4" <?php echo ($properties['bathrooms']=='4')?'selected':''; ?>>4</option>
                      </select>
										</div>
									</div>									
									
									<div class="form-group" id="balcony_div">
										<label class="col-sm-3 control-label">Balcony</label>
										<div class="col-sm-9">
											 <select class="form-control basic-select" id="balcony" name="balcony" required>
                        <option value="">Select Availability</option>
                        <option value="Yes"  <?php echo ($properties['balcony']=='Yes')?'selected':''; ?>>Yes</option>
                        <option value="No"  <?php echo ($properties['balcony']=='No')?'selected':''; ?>>No</option>
                      </select>
										</div>
									</div>									
									
									
									<div class="form-group"  id="parking_div">
										<label class="col-sm-3 control-label">Parking</label>
										<div class="col-sm-9">
											 <select class="form-control basic-select" id="parking" name="parking" required>
                        <option value="">Select Availability</option>
                        <option value="Yes" <?php echo ($properties['parking']=='Yes')?'selected':''; ?>>Yes</option>
                        <option value="No" <?php echo ($properties['parking']=='No')?'selected':''; ?>>No</option>
                      </select>
										</div>
									</div>									
									
									
									<div class="form-group"  id="car_coverd_div">
										<label class="col-sm-3 control-label">Cars Coverd</label>
										<div class="col-sm-9">
											 <select class="form-control basic-select" id="car_coverd" name="car_coverd" required>
                        <option value="">Select Value</option>
                        <option value="1" <?php echo ($properties['car_coverd']=='1')?'selected':''; ?>>1</option>
                        <option value="2" <?php echo ($properties['car_coverd']=='2')?'selected':''; ?>>2</option>
                        <option value="3" <?php echo ($properties['car_coverd']=='3')?'selected':''; ?>>4</option>
                        <option value="4" <?php echo ($properties['car_coverd']=='4')?'selected':''; ?>>4</option>
                      </select>
										</div>
									</div>									
									
									<div class="form-group">
										<label class="col-sm-3 control-label">GST Charges</label>
										<div class="col-sm-9">
											 <select class="form-control basic-select" name="gst_charges" id="gst_charges" required>
                          <option value="">Select GST Percentage</option>
                        <option value="1%" <?php echo ($properties['gst_charges']=='1%')?'selected':''; ?>>1%</option>
                        <option value="2%" <?php echo ($properties['gst_charges']=='2%')?'selected':''; ?>>2%</option>
                        <option value="3%" <?php echo ($properties['gst_charges']=='3%')?'selected':''; ?>>3%</option>
                        <option value="4%" <?php echo ($properties['gst_charges']=='4%')?'selected':''; ?>>4%</option>
                        <option value="5%" <?php echo ($properties['gst_charges']=='5%')?'selected':''; ?>>5%</option>
                        <option value="6%" <?php echo ($properties['gst_charges']=='6%')?'selected':''; ?>>6%</option>
                        <option value="7%" <?php echo ($properties['gst_charges']=='7%')?'selected':''; ?>>7%</option>
                        <option value="8%" <?php echo ($properties['gst_charges']=='8%')?'selected':''; ?>>8%</option>
                      </select>
										</div>
									</div>									
									
									
									
									<div class="form-group">
										<label class="col-sm-3 control-label">Approved By</label>
										<div class="col-sm-9">
											 <select class="form-control basic-select" name="approved_by" id="approved_by" required>
                          <option value="">Select Authority</option>
                        <option value="GHMC" <?php echo ($properties['approved_by']=='GHMC')?'selected':''; ?>>GHMC</option>
                        <option value="HMDA" <?php echo ($properties['approved_by']=='HMDA')?'selected':''; ?>>HMDA</option>
                        <option value="DTCP"  <?php echo ($properties['approved_by']=='DTCP')?'selected':''; ?>>DTCP</option>
                        <option value="MUNICIPALITY" <?php echo ($properties['approved_by']=='MUNICIPALITY')?'selected':''; ?>>MUNICIPALITY</option>
                        <option value="GP" <?php echo ($properties['approved_by']=='GP')?'selected':''; ?>>GP</option>
                        <option value="CITY DEVELOPMENT AUTHORITY" <?php echo ($properties['approved_by']=='CITY DEVELOPMENT AUTHORITY')?'selected':''; ?>>CITY DEVELOPMENT AUTHORITY</option>
                      </select>
										</div>
									</div>									
									
									
									<div class="form-group">
										<label class="col-sm-3 control-label">Position of Flat Status</label>
										<div class="col-sm-9">
											 <select class="form-control basic-select" id="position_of_flat" name="position_of_flat" required>
                        <option value="">Select Position Status</option>
                        <option value="Ready to Move" <?php echo ($properties['position_of_flat']=='Ready to Move')?'selected':''; ?>>Ready to Move</option>
                        <option value="Under Construction" <?php echo ($properties['position_of_flat']=='Under Construction')?'selected':''; ?>>Under Construction</option>
                      </select>
										</div>
									</div>									
									
									
																		
									<div class="form-group"  id="description_div">
										<label class="col-sm-3 control-label">Description</label>
										<div class="col-sm-9">
											 <textarea class="form-control" id="description" name="description" ><?php echo $properties['rental_income_avg']; ?></textarea>
										</div>
									</div>									
									
									
									<div class="form-group">
										<label class="col-sm-3 control-label">Time to Handover</label>
										<div class="col-sm-9">
											 <select class="form-control basic-select" id="time_to_handover" name="time_to_handover" required>
                        <option value="">Select Handover Time</option>
                        <option value="Immediately" <?php echo ($properties['time_to_handover']=='Immediately')?'selected':''; ?>>Immeaditily</option>
                        <option value="3" <?php echo ($properties['time_to_handover']=='3')?'selected':''; ?>>3 Months</option>
                        <option value="6" <?php echo ($properties['time_to_handover']=='6')?'selected':''; ?>>6 Months</option>
                        <option value="12" <?php echo ($properties['time_to_handover']=='12')?'selected':''; ?>>12 Months</option>
                        <option value="18" <?php echo ($properties['time_to_handover']=='18')?'selected':''; ?>>18 Months</option>
                        <option value="24" <?php echo ($properties['time_to_handover']=='24')?'selected':''; ?>>24 Months</option>
                        <option value="36" <?php echo ($properties['time_to_handover']=='36')?'selected':''; ?>>36 Months</option>
                      </select>
										</div>
									</div>									
									
									
									<div class="form-group">
										<div class="col-sm-4 col-sm-offset-2">
											<!--<button class="btn btn-white" type="reset">Reset</button>-->
											<input type="hidden" name="property_id" id="property_id" value="<?php echo $properties['id'];?>">
											<button class="btn btn-primary" name="propert_submit_btn" type="submit">Save</button>
										</div>
									</div>
								</form>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
 
<script src="<?php echo base_url()?>externals/js/plugins/summernote/summernote.min.js"></script>
  
<script>
$(document).ready(function(){

	$('.txtcls').summernote();

});
var edit = function() {
	$('.click2edit').summernote({focus: true});
};
var save = function() {
	var aHTML = $('.click2edit').code(); //save HTML If you need(aHTML: array).
	$('.click2edit').destroy();
};
function bhanu(){
//alert('fdxsghbdf');
	//Get reference of FileUpload.
	var fileUpload = $("#mainImage")[0];
	//Check whether HTML5 is supported.
	if (typeof (fileUpload.files) != "undefined") {
		//Initiate the FileReader object.
		var reader = new FileReader();
		//Read the contents of Image File.
		reader.readAsDataURL(fileUpload.files[0]);
		reader.onload = function (e) {
			//Initiate the JavaScript Image object.
			var image = new Image();
			//Set the Base64 string return from FileReader as source.
			image.src = e.target.result;
			image.onload = function () {
				//Determine the Height and Width.
				var height = this.height;
				var width = this.width;
				   if (height < 250 || height > 260 || width < 250 || width >  260){
					alert("width and height should be 256 X 256 Px.");
					$("#mainImage").val('');
					return false;
				}
				//alert("Uploaded image has valid Height and Width.");
				return true;
			};
		}
	} else {
		alert("This browser does not support HTML5.");
		return false;
	}
}
</script>

   <!-- Template Scripts-->
  <script src="https://hikeassets.com/assets/js/property_form.js"></script>
  <script>
       
    /*Autocomplete google location address*/
  
      var placeSearch, autocomplete;
      
    function initAutocomplete() {
        // Create the autocomplete object, restricting the search to geographical
        // location types.
        autocomplete = new google.maps.places.Autocomplete((document.getElementById('autocomplete1')),
            {types: ['geocode'],
		  componentRestrictions: {country: "in"}
		});
        
            
         autocomplete2 = new google.maps.places.Autocomplete(document.getElementById('autocomplete2'),  {types: ['geocode'],
		  componentRestrictions: {country: "au"}
		});   


        autocomplete3 = new google.maps.places.Autocomplete(document.getElementById('autocomplete3'),  {types: ['geocode'],
		  componentRestrictions: {country: "au"}
		});   

        autocomplete4 = new google.maps.places.Autocomplete(document.getElementById('autocomplete4'),  {types: ['geocode'],
		  componentRestrictions: {country: "au"}
		});    

        
        // When the user selects an address from the dropdown, populate the address
        // fields in the form.
        autocomplete.addListener('place_changed', fillInAddress);
       
        google.maps.event.addListener(autocomplete2, 'place_changed', function() {
  fillInAddress();
});
      }
      
      function fillInAddress() {
  // Get the place details from the autocomplete object.
  var place = autocomplete.getPlace();

  for (var component in componentForm) {
    document.getElementById(component).value = '';
    document.getElementById(component).disabled = false;
  }

  // Get each component of the address from the place details,
  // and then fill-in the corresponding field on the form.
  for (var i = 0; i < place.address_components.length; i++) {
    var addressType = place.address_components[i].types[0];
    if (componentForm[addressType]) {
      var val = place.address_components[i][componentForm[addressType]];
      document.getElementById(addressType).value = val;
    }
  }
}

function geolocate() {
  if (navigator.geolocation) {
    navigator.geolocation.getCurrentPosition(function(position) {
      var geolocation = {
        lat: position.coords.latitude,
        lng: position.coords.longitude
      };
      var circle = new google.maps.Circle(
          {center: geolocation, radius: position.coords.accuracy});
      autocomplete.setBounds(circle.getBounds());
    });
  }
}
      
  
  </script>
  
   <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDbpw2uyXuBG8gKl9ChiXnKxuK9hSgzXcQ&libraries=places&callback=initAutocomplete"
        async defer></script>