<style>
.center{
	text-align:center;
}
</style>
<link href="<?php echo base_url()?>externals/css/plugins/dataTables/dataTables.bootstrap.css" rel="stylesheet">
<link href="<?php echo base_url()?>externals/css/plugins/dataTables/dataTables.responsive.css" rel="stylesheet">
<link href="<?php echo base_url()?>externals/css/plugins/dataTables/dataTables.tableTools.min.css" rel="stylesheet">

	<div class="row wrapper border-bottom white-bg page-heading">
		<div class="col-sm-4">
			<h2>Buy Property Quote</h2>
			<ol class="breadcrumb">
				<li>
					<a href="<?php echo base_url()?>">Dashboard</a>
				</li>
				<li class="active">
					<strong>Buy Property Quote</strong>
				</li>
			</ol>
		</div>
	</div>
	<div class="row">
		<div class="col-lg-12">
			<div class="wrapper wrapper-content">
				<div class="row">
					<div class="ibox">                        
						<div class="ibox-content">
						<?php
						if(@$this->session->userdata("success") != '')
						{
						?>
							<div class="alert alert-success alert-dismissable">
                                <button aria-hidden="true" data-dismiss="alert" class="close" type="button">×</button>
                                <?php
								echo @$this->session->userdata("success");
								@$this->session->unset_userdata("success");
								?>
                            </div>
						<?php
						}
						if(@$this->session->userdata("fail") != '')
						{
						?>
							<div class="alert alert-danger alert-dismissable">
                                <button aria-hidden="true" data-dismiss="alert" class="close" type="button">×</button>
                                <?php
								echo @$this->session->userdata("fail");
								@$this->session->unset_userdata("fail");
								?>
                            </div>
						<?php
						}
						?>
							<table class="table table-striped table-bordered table-hover " id="editable" >
								<thead>
									<tr>
										<th class="center">S.No</th>
										<th class="center">User Id</th>
										<th class="center">Property Id</th>
										<th class="center">User Name</th>
										<th class="center">Mobile Number</th>
										<th class="center">Property Type</th>
										<th class="center">Property Price</th>
										<th class="center">Property Requirements</th>
										<th class="center">Property Address</th>
										<th class="center">Description</th>
										<th class="center">Entered</th>
										<th class="center">Actions</th>
									</tr>
								</thead>
								<tbody>
								<?php
								if(@sizeOf($buy_quote) > 0)
								{
									for($a=0;$a<@sizeOf($buy_quote);$a++)
									{
								?>
									<tr class="gradeX">
										<td class="center">
											<?php echo @($a+1);?>
										</td>
										<td class="center">
											<?php echo @$buy_quote[$a]->user_id;?>
										</td>

                                        <td class="center">
											<?php echo @$buy_quote[$a]->prop_id;?>
										</td>										<td class="center">
											<a href="<?php echo base_url(); ?>index.php/users/user_data/<?php echo @$buy_quote[$a]->user_id;?>" ><?php echo @$buy_quote[$a]->user_name;?></a>
										</td>
										<td class="center">
											<?php echo @$buy_quote[$a]->phone;?>
										</td>
										<td class="center">
											<?php echo @$buy_quote[$a]->property_type;?>
										</td>
										<td class="center">
											<?php echo @$buy_quote[$a]->property_price;?>
										</td>
										<td class="center">
										   <?php if(@$buy_quote[$a]->bedrooms != ""){ ?>
											Bedrooms(<?php echo @$buy_quote[$a]->bedrooms;?>),<br> <?php } ?>
											
											 <?php if(@$buy_quote[$a]->bathrooms != ""){ ?>
											Bathrooms(<?php echo @$buy_quote[$a]->bathrooms;?>),<br> <?php } ?>
											
											
											 <?php if(@$buy_quote[$a]->balcony != ""){ ?>
											Balcony(<?php echo @$buy_quote[$a]->balcony;?>),<br> <?php } ?>
											
											
											
											 <?php if(@$buy_quote[$a]->parking != ""){ ?>
											Parking(<?php echo @$buy_quote[$a]->parking;?>),<br> <?php } ?>
											
											
											 <?php if(@$buy_quote[$a]->approved_by != ""){ ?>
											Approved_by(<?php echo @$buy_quote[$a]->approved_by;?>),<br> <?php } ?>
											
											 <?php if(@$buy_quote[$a]->facing != ""){ ?>
											Facing(<?php echo @$buy_quote[$a]->facing;?>),<br> <?php } ?>
											
											
										</td>
										
									
										
										<td class="center">
											<?php echo @$buy_quote[$a]->friendly_addr;?>,	<?php echo @$buy_quote[$a]->place;?>,	<?php echo @$buy_quote[$a]->district;?>, <?php echo @$buy_quote[$a]->state;?>
										</td>
										
											<td class="center">
											<?php echo @$buy_quote[$a]->description;?>
										</td>
										<td class="center" width="120px">
											<?php echo date('d-m-Y', strtotime(@$buy_quote[$a]->created));
											
											?>
										</td>
										
										<td class="center">
											<a href="<?php echo base_url()?>index.php/properties/deletebuy_quote/<?php echo @$buy_quote[$a]->prop_id;?>"><i class="fa fa-trash"></i></a> 
											
										</td>
									</tr>
								<?php
									}
								}
								else
								{
									echo '<tr class="gradeX"><td colspan="5" style="color:red" class="center"><b>No Records Found</b></td></tr>';
								}
								?>
								</tbody>
							</table>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>

<script src="<?php echo base_url()?>externals/js/plugins/jeditable/jquery.jeditable.js"></script>
<script src="<?php echo base_url()?>externals/js/plugins/dataTables/jquery.dataTables.js"></script>
<script src="<?php echo base_url()?>externals/js/plugins/dataTables/dataTables.bootstrap.js"></script>
<script src="<?php echo base_url()?>externals/js/plugins/dataTables/dataTables.responsive.js"></script>
<script src="<?php echo base_url()?>externals/js/plugins/dataTables/dataTables.tableTools.min.js"></script>
<script>
$(document).ready(function() {
	$('.dataTables-example').dataTable({
		responsive: true,
		"dom": 'T<"clear">lfrtip',
		"tableTools": {
			"sSwfPath": "js/plugins/dataTables/swf/copy_csv_xls_pdf.swf"
		}
	});

	/* Init DataTables */
	var oTable = $('#editable').dataTable();

	/* Apply the jEditable handlers to the table */
	/*oTable.$('td').editable( '../example_ajax.php', {
		"callback": function( sValue, y ) {
			var aPos = oTable.fnGetPosition( this );
			oTable.fnUpdate( sValue, aPos[0], aPos[1] );
		},
		"submitdata": function ( value, settings ) {
			return {
				"row_id": this.parentNode.getAttribute('id'),
				"column": oTable.fnGetPosition( this )[2]
			};
		},

		"width": "90%",
		"height": "100%"
	} );*/


});

function fnClickAddRow() {
	$('#editable').dataTable().fnAddData( [
		"Custom row",
		"New row",
		"New row",
		"New row",
		"New row" ] );

}
</script>
	