<style>
.center{
	text-align:center;
}
</style>
	<div class="row wrapper border-bottom white-bg page-heading">
		<div class="col-sm-4">
			<h2>Job Applications</h2>
			<ol class="breadcrumb">
				<li>
					<a href="<?php echo base_url()?>">Dashboard</a>
				</li>
				<li>
					<a href="<?php echo base_url()?>index.php/applications">User Applications</a>
				</li>
				<li class="active">
					<strong>Questionnaire</strong>
				</li>
			</ol>
		</div>
		<div class="col-sm-4 pull-right">
		</div>
	</div>
	<div class="row">
		<div class="col-lg-12">
			<div class="wrapper wrapper-content">
				<div class="row">
					<div class="ibox">                        
						<div class="ibox-content">
						<?php
						if(@$this->session->userdata("success") != '')
						{
						?>
							<div class="alert alert-success alert-dismissable">
                                <button aria-hidden="true" data-dismiss="alert" class="close" type="button">×</button>
                                <?php
								echo @$this->session->userdata("success");
								@$this->session->unset_userdata("success");
								?>
                            </div>
						<?php
						}
						if(@$this->session->userdata("fail") != '')
						{
						?>
							<div class="alert alert-danger alert-dismissable">
                                <button aria-hidden="true" data-dismiss="alert" class="close" type="button">×</button>
                                <?php
								echo @$this->session->userdata("fail");
								@$this->session->unset_userdata("fail");
								?>
                            </div>
						<?php
						}
						?>
							
								<?php
								if(@sizeOf($details) > 0)
								{
									for($i=0;$i<sizeOf($details);$i++)
									{
										if($i % 2 == 0)
										{
											$bhe="background-color:#f5eeee";
										}
										else
										{
											$bhe="";
										}
								?>
									<div class="row">
										<div class="col-sm-12" style="margin-bottom:1%;border: 1px solid #ccc;padding: 13px;<?php echo @$bhe;?>">
											<h3><?php echo @$i+1?>. <?php echo @$details[$i]->question;?></h3>
											<p style="margin-top:2%;"><?php echo @$details[$i]->answer;?></p>
										</div>
									</div>
									<hr>
								<?php
									}
								}
								?>
								</tbody>
							</table>
						</div>
					</div>
				</div>
			</div>
