<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Applications extends MX_Controller {
	public function __construct()
	{
		parent::__construct();
		$this->load->model("applications_model");
		//$this->load->model("category/category_model");
	}
	public function index()
	{
		if(@$this->session->userdata("is_logged_in") == 1)
		{
			$data["menu"]="applications";
			$this->load->view('dashboard/header',$data);
			$data["applications"] = $this->applications_model->getapplications();			
			$this->load->view('index', $data);
			$this->load->view('dashboard/footer');
		}
		else
		{
			redirect(base_url()."index.php/login");
		}
	}
	
	public function deleteapplications($bannerid)
	{
		//$bannerid=str_replace("_","=",base64_decode($bannerid));		
		$test=$this->applications_model->deleteapplications($bannerid);
		if($test == 1)
		{
			$this->session->set_userdata(array(
					"success" => "Successfully Deleted"
					));
				redirect(base_url()."index.php/applications");
		}
		else
		{
			$this->session->set_userdata(array(
					"faile" => "Failed to Delete data"
				));				
			redirect(base_url()."index.php/applications");
		}
		
	}
	
	public function viewDetails($appId)
	{
		if(@$this->session->userdata("is_logged_in") == 1)
		{
			$data["menu"]="applications";
			$this->load->view('dashboard/header',$data);
			$data["details"] = $this->applications_model->getQuestionnaire($appId);			
			$this->load->view('details', $data);
			$this->load->view('dashboard/footer');
		}
		else
		{
			redirect(base_url()."index.php/login");
		}
	}
}
