<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class applications_model extends CI_Model {

	
	public function getapplications()
	{
		$this->db->select("*")->from("job_applications")->where(array("status" => 1))->order_by("id","DESC");		
		$query=$this->db->get();
		if($query->num_rows() > 0)
		{
			return $query->result();
		}
		else{
			return array();
		}
	}
	
	public function deleteapplications($bannerid)
	{		
		$deletequery=$this->db->delete("job_applications",array("id" => $bannerid));
		if($deletequery)
		{
			return 1;
		}
		else
		{
			return 0;
		}
	}
	
	public function getQuestionnaire($appId)
	{
		$this->db->select("*")->from("user_answers")->where(array("app_id" => $appId));		
		$query=$this->db->get();
		if($query->num_rows() > 0)
		{
			return $query->result();
		}
		else{
			return array();
		}
	}
}