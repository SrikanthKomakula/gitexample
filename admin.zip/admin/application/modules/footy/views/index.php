<style>
.center{
	text-align:center;
}
</style>

	<div class="row wrapper border-bottom white-bg page-heading">
		<div class="col-sm-4">
			<h2>Footer Address</h2>
			<ol class="breadcrumb">
				<li>
					<a href="<?php echo base_url()?>">Dashboard</a>
				</li>
				<li class="active">
					<strong>Footer Address</strong>
				</li>
			</ol>
		</div>
		<div class="col-sm-4 pull-right">
			<?php
			if(@sizeOf($footy) == 0)
			{
			?>
			<h2>			
				<a href="<?php echo base_url()?>index.php/footy/createfooty" class="btn btn-w-m btn-primary pull-right">Add Address</a>		
			</h2>
			<?php
			}
			?>
		</div>
	</div>
	<div class="row">
		<div class="col-lg-12">
			<div class="wrapper wrapper-content">
				<div class="row">
					<div class="ibox">                        
						<div class="ibox-content">
						<?php
						if(@$this->session->userdata("success") != '')
						{
						?>
							<div class="alert alert-success alert-dismissable">
                                <button aria-hidden="true" data-dismiss="alert" class="close" type="button">×</button>
                                <?php
								echo @$this->session->userdata("success");
								@$this->session->unset_userdata("success");
								?>
                            </div>
						<?php
						}
						if(@$this->session->userdata("fail") != '')
						{
						?>
							<div class="alert alert-danger alert-dismissable">
                                <button aria-hidden="true" data-dismiss="alert" class="close" type="button">×</button>
                                <?php
								echo @$this->session->userdata("fail");
								@$this->session->unset_userdata("fail");
								?>
                            </div>
						<?php
						}
						?>
							<table class="table table-striped table-bordered table-hover " id="editable" >
								<thead>
									<tr>
										<th class="center">S.No</th>
										<th class="center">Write Us</th>
										<th class="center">Call Us</th>
										<th class="center">Visit Us</th>
										<th class="center">Copy Rights</th>
										<th class="center">Edit</th>
									</tr>
								</thead>
								<tbody>
								<?php
								if(@sizeOf($footy) > 0)
								{
									for($i=0;$i<sizeOf($footy);$i++)
									{
								?>
									<tr class="gradeX">
										<td class="center"><?php echo ($i+1)?></td>	
										
										<td class="center"><?php echo @$footy[$i]->write_1;?><br><?php echo @$footy[$i]->write_2;?></td>
										<td class="center"><?php echo @$footy[$i]->call_1;?><br><?php echo @$footy[$i]->call_2;?></td>
										<td class="center"><?php echo @$footy[$i]->vist;?></td>
										<td class="center"><?php echo @$footy[$i]->map_lan;?></td>
										<td class="center">
											<a href="<?php echo base_url()?>index.php/footy/editfooty/<?php echo @$footy[$i]->id;?>"><i class="fa fa-edit"></i></a> 
										</td>
									</tr>
								<?php
									}
								}
								?>
								</tbody>
							</table>
						</div>
					</div>
				</div>
			</div>

