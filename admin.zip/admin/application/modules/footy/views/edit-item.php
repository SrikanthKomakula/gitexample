<!--<link href="<?php //echo base_url()?>externals/css/plugins/summernote/summernote.css" rel="stylesheet">
<link href="<?php //echo base_url()?>externals/css/plugins/summernote/summernote-bs3.css" rel="stylesheet">-->
	<div class="row wrapper border-bottom white-bg page-heading">
		<div class="col-sm-4">
			<h2>Edit Contact</h2>
			<ol class="breadcrumb">
				<li>
					<a href="<?php echo base_url();?>">Dashboard</a>
				</li>
				<li>
					<a href="<?php echo base_url();?>index.php/footy">Footer Address</a>
				</li>
				<li class="active">
					<strong>Edit Contact</strong>
				</li>
			</ol>
		</div>
		<div class="col-sm-4 pull-right">
			<h2>
				<a href="<?php echo base_url()?>index.php/footy" class="btn btn-w-m btn-default pull-right">Back to List</a>
			</h2>
		</div>
	</div>
	<div class="row">
		<div class="col-lg-12">
			<div class="wrapper wrapper-content">
				<div class="row">
					<div class="col-lg-9">
						<div class="ibox">
							
							<div class="ibox-content">
								
								<form method="POST" action="<?php echo base_url()?>index.php/footy/updatefooty" class="form-horizontal" enctype="multipart/form-data">
																	
									<div class="form-group">
										<label class="col-sm-3 control-label">Office Email</label>
										<div class="col-sm-9">
											<input type="email" name="write_1" id="write_1" class="form-control txtcls" required value="<?php echo @$info[0]->write_1;?>"/>
										</div>
									</div>									
									<div class="hr-line-dashed"></div>
								
									<div class="form-group">
										<label class="col-sm-3 control-label">Support Email</label>
										<div class="col-sm-9">
											<input type="email" name="write_2" id="write_2" class="form-control txtcls" required value="<?php echo @$info[0]->write_2;?>"/>
										</div>
									</div>									
									<div class="hr-line-dashed"></div>
									
									<div class="form-group">
										<label class="col-sm-3 control-label">Phone 1</label>
										<div class="col-sm-9">
											<input type="text" name="call_1" id="call_1" class="form-control txtcls" required value="<?php echo @$info[0]->call_1;?>"/>
										</div>
									</div>									
									<div class="hr-line-dashed"></div>									
									
									<div class="form-group">
										<label class="col-sm-3 control-label">Phone 2</label>
										<div class="col-sm-9">
											<input type="text" name="call_2" id="call_2" class="form-control txtcls" required value="<?php echo @$info[0]->call_2;?>"/>
										</div>
									</div>									
									<div class="hr-line-dashed"></div>
									
									<div class="form-group">
										<label class="col-sm-3 control-label">Address</label>
										<div class="col-sm-9">
											<textarea name="vist" id="vist" class="form-control txtcls" required><?php echo @$info[0]->vist;?></textarea>
										</div>
									</div>									
									<div class="hr-line-dashed"></div>
									
									<div class="form-group">
										<label class="col-sm-3 control-label">Copy Rights</label>
										<div class="col-sm-9">
											<input type="text" name="map_lan" id="map_lan" class="form-control txtcls" value="<?php echo @$info[0]->map_lan;?>"/>
										</div>
									</div>									
									<div class="hr-line-dashed"></div>
									
									<!--<div class="form-group">
										<label class="col-sm-3 control-label">Google Map Iframe</label>
										<div class="col-sm-9">
											<textarea name="map_lat" id="map_lat" class="form-control txtcls" required><?php echo @$info[0]->map_lat;?></textarea>
										</div>
									</div>									
									<div class="hr-line-dashed"></div>-->
									
									<div class="form-group">
										<div class="col-sm-4 col-sm-offset-2">
											<!--<button class="btn btn-white" type="reset">Reset</button>-->
											<input type="hidden" name="footyid" id="footyid" value="<?php echo @$bannerid;?>">
											<button class="btn btn-primary" type="submit">Save</button>
										</div>
									</div>
								</form>
							</div>
						</div>
					</div>
				</div>
			</div>


<!--<script src="<?php //echo base_url()?>externals/js/plugins/summernote/summernote.min.js"></script>-->
  
<script>
/* $(document).ready(function(){

	$('.txtcls').summernote();

});
var edit = function() {
	$('.click2edit').summernote({focus: true});
};
var save = function() {
	var aHTML = $('.click2edit').code(); //save HTML If you need(aHTML: array).
	$('.click2edit').destroy();
} */;
function bhanu(){
//alert('fdxsghbdf');
	//Get reference of FileUpload.
	var fileUpload = $("#mainImage")[0];
	//Check whether HTML5 is supported.
	if (typeof (fileUpload.files) != "undefined") {
		//Initiate the FileReader object.
		var reader = new FileReader();
		//Read the contents of Image File.
		reader.readAsDataURL(fileUpload.files[0]);
		reader.onload = function (e) {
			//Initiate the JavaScript Image object.
			var image = new Image();
			//Set the Base64 string return from FileReader as source.
			image.src = e.target.result;
			image.onload = function () {
				//Determine the Height and Width.
				var height = this.height;
				var width = this.width;
				   if (height < 195 || height > 215 || width < 290 || width >  310){
					alert("width and height should be 300 X 205 Px.");
					$("#mainImage").val('');
					return false;
				}
				//alert("Uploaded image has valid Height and Width.");
				return true;
			};
		}
	} else {
		alert("This browser does not support HTML5.");
		return false;
	}
}
</script>