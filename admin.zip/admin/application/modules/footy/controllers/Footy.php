<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Footy extends MX_Controller {
	public function __construct()
	{
		parent::__construct();
		$this->load->model("footy_model");
		//$this->load->model("category/category_model");
	}
	public function index()
	{
		if(@$this->session->userdata("is_logged_in") == 1)
		{
			$data["menu"]="footy";
			$this->load->view('dashboard/header',$data);
			$data["footy"] = $this->footy_model->getfooty();			
			$this->load->view('index', $data);
			$this->load->view('dashboard/footer');
		}
		else
		{
			redirect(base_url()."index.php/login");
		}
	}
	
	public function createfooty()
	{
		if(@$this->session->userdata("is_logged_in") == 1)
		{
			$data["menu"]="footy";
			$this->load->view('dashboard/header',$data);
			$this->load->view('create-item');
			$this->load->view('dashboard/footer');
		}
		else
		{
			redirect(base_url()."index.php/login");
		}
	}
	
	public function savefooty()
	{
		
		$params = array(			
			"write_1" => $this->input->post("write_1"),			
			"write_2" => $this->input->post("write_2"),			
			"call_1" => $this->input->post("call_1"),			
			"call_2" => $this->input->post("call_2"),			
			"vist" => $this->input->post("vist"),			
			//"map_lat" => $this->input->post("map_lat"),			
			"map_lan" => $this->input->post("map_lan"),			
			"created_date" => @date("Y-m-d H:i:s"),
		);
		$table="footer";
		$infootyt = $this->footy_model->storeItems($table,$params);
		if($infootyt == 1)
		{
			@move_uploaded_file($_FILES["mainImage"]["tmp_name"],"uploads/aboutus/".$banner_img);
			$this->session->set_userdata(array(
				"success" => "Successfully Saved Data"
			));
			redirect(base_url()."index.php/footy");
		}
		else{
			$this->session->set_userdata(array(
				"faile" => "Failed to save the data"
			));
			redirect(base_url()."index.php/footy");
		}
	}
	
	public function editfooty($bannerid)
	{
		if(@$this->session->userdata("is_logged_in") == 1)
		{
			$data["menu"]="footy";
			$this->load->view('dashboard/header',$data);
			$data["info"]=$this->footy_model->getInfobyId($bannerid);
			$data["bannerid"]=$bannerid;
			$this->load->view('edit-item',$data);
			$this->load->view('dashboard/footer');
		}
		else
		{
			redirect(base_url()."index.php/login");
		}
	}
	
	public function updatefooty()
	{
		if($this->session->userdata("is_logged_in") != 1)
		{
			redirect(base_url()."index.php/login");
		}
		else
		{	
			$bannerid=$this->input->post("footyid");
			
			$params=array(
				"write_1" => $this->input->post("write_1"),			
				"write_2" => $this->input->post("write_2"),			
				"call_1" => $this->input->post("call_1"),			
				"call_2" => $this->input->post("call_2"),			
				"vist" => $this->input->post("vist"),			
				//"map_lat" => $this->input->post("map_lat"),			
				"map_lan" => $this->input->post("map_lan"),				
			);
			//print_r($params);die();
			$table="footer";
			$footy=$this->footy_model->updateItems($table,$params,$bannerid);
			if($footy == 1)
			{
				$this->session->set_userdata(array(
					"success" => "Successfully Data Updated"
					));
				redirect(base_url()."index.php/footy");
			}
			else
			{
				$this->session->set_userdata(array(
					"faile" => "Failed to Update data"
				));				
				redirect(base_url()."index.php/footy");
			}
			
		}
	}
	
	public function deletefooty($bannerid)
	{
		//$bannerid=str_replace("_","=",base64_decode($bannerid));		
		$test=$this->footy_model->deletefooty($bannerid);
		if($test == 1)
		{
			$this->session->set_userdata(array(
					"success" => "Successfully Deleted"
					));
				redirect(base_url()."index.php/footy");
		}
		else
		{
			$this->session->set_userdata(array(
					"faile" => "Failed to Delete data"
				));				
			redirect(base_url()."index.php/footy");
		}
		
	}
}
