<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Testimonials_model extends CI_Model {

	
	public function gettestimonials()
	{
		$this->db->select("*")->from("family_cms")->where(array("page_type" => 8))->order_by("data_seq","ASC");		
		$query=$this->db->get();
		if($query->num_rows() > 0)
		{
			return $query->result();
		}
		else{
			return array();
		}
	}
	

	
	public function storeItems($table,$params)
	{
		$query=$this->db->insert($table,$params);
		if($query)
		{
			return 1;
		}
		else{
			return 0;
		}
	}
	
	public function updateItems($table,$params,$bannerid)
	{
		$query=$this->db->update($table,$params,array("id" => $bannerid));
		if($query)
		{
			return 1;
		}
		else{
			return 0;
		}
	}
	
	public function getInfobyId($bannerid)
	{
		$query = $this->db->select("*")->from("family_cms")->where("id",$bannerid)->get();
		if($query->num_rows() > 0)
		{
			return $query->result();
		}
		else{
			return array();
		}
	}
	
	public function deletetestimonials($bannerid)
	{		
		$this->db->select("*")->from("family_cms")->where(array("id" => $bannerid));		
		$query=$this->db->get();
		
		if($query->num_rows() == 1)
		{
			$result=$query->result();
			@unlink(FCPATH . 'uploads/aboutus/' . $result[0]->cms_img);					
		}
		$deletequery=$this->db->delete("family_cms",array("id" => $bannerid));
		if($deletequery)
		{
			return 1;
		}
		else
		{
			return 0;
		}
	}
	
	public function removeExistsimage($bannerid)
	{
		$this->db->select("*")->from("family_cms")->where(array("id" => $bannerid));
		$query=$this->db->get();
		//echo $this->db->last_query();die();
		if($query->num_rows() > 0)
		{
			$result=$query->result();		
			$delete=@unlink(FCPATH . 'uploads/aboutus/' . $result[0]->cms_img);
			if($delete)
			{
				return 1;
			}
			else
			{
				return 0;
			}
		}
	}
}