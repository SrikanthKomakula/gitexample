<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Testimonials extends MX_Controller {
	public function __construct()
	{
		parent::__construct();
		$this->load->model("testimonials_model");
		//$this->load->model("category/category_model");
	}
	public function index()
	{
		if(@$this->session->userdata("is_logged_in") == 1)
		{
			$data["menu"]="testimonials";
			$this->load->view('dashboard/header',$data);
			$data["testimonials"] = $this->testimonials_model->gettestimonials();
		
			$this->load->view('index', $data);
			$this->load->view('dashboard/footer');
		}
		else
		{
			redirect(base_url()."index.php/login");
		}
	}
	
	public function createtestimonials()
	{
		if(@$this->session->userdata("is_logged_in") == 1)
		{
			$data["menu"]="testimonials";
			$this->load->view('dashboard/header',$data);
			$this->load->view('create-item');
			$this->load->view('dashboard/footer');
		}
		else
		{
			redirect(base_url()."index.php/login");
		}
	}
	
	public function savetestimonials()
	{
		
		$testimonial=$this->testimonials_model->gettestimonials();
		$data_seq=@sizeOf($testimonial)+1;
		$params = array(
			"data_seq" => $data_seq,
			"cms_title" => $this->input->post("cms_title"),			
			"cms_designation" => $this->input->post("cms_designation"),			
			"cms_desc" => $this->input->post("cms_desc"),			
					
			"page_type" => 8,			
			"created_date" => @date("Y-m-d H:i:s"),
		);
		$table="family_cms";
		$inteacherst = $this->testimonials_model->storeItems($table,$params);
		if($inteacherst == 1)
		{
			$this->session->set_userdata(array(
				"success" => "Successfully Saved Data"
			));
			redirect(base_url()."index.php/testimonials");
		}
		else{
			$this->session->set_userdata(array(
				"faile" => "Failed to save the data"
			));
			redirect(base_url()."index.php/testimonials");
		}
	}
	

	
	public function edittestimonials($bannerid)
	{
		if(@$this->session->userdata("is_logged_in") == 1)
		{
			$data["menu"]="testimonials";
			$this->load->view('dashboard/header',$data);
			$data["info"]=$this->testimonials_model->getInfobyId($bannerid);
			$data["bannerid"]=$bannerid;
			
			$this->load->view('edit-item',$data);
			$this->load->view('dashboard/footer');
		}
		else
		{
			redirect(base_url()."index.php/login");
		}
	}
	
	public function updatetestimonials()
	{
		if($this->session->userdata("is_logged_in") != 1)
		{
			redirect(base_url()."index.php/login");
		}
		else
		{	
			$bannerid=$this->input->post("testimonialsid");
			
			
			$params=array(				
				"cms_title" => $this->input->post("cms_title"),			
				"cms_designation" => $this->input->post("cms_designation"),			
				"cms_desc" => $this->input->post("cms_desc"),			
			
				"page_type" => 8,				
			);
			//print_r($params);die();
			$table="family_cms";
			$teachers=$this->testimonials_model->updateItems($table,$params,$bannerid);
			if($teachers == 1)
			{
				$this->session->set_userdata(array(
					"success" => "Successfully Data Updated"
				));
				redirect(base_url()."index.php/testimonials");
			}
			else
			{
				$this->session->set_userdata(array(
					"faile" => "Failed to Update data"
				));				
				redirect(base_url()."index.php/testimonials");
			}
			
		}
	}
	
	public function deletetestimonials($bannerid)
	{
		//$bannerid=str_replace("_","=",base64_decode($bannerid));		
		$test=$this->testimonials_model->deletetestimonials($bannerid);
		if($test == 1)
		{
			$this->session->set_userdata(array(
				"success" => "Successfully Deleted"
			));
			redirect(base_url()."index.php/testimonials");
		}
		else
		{
			$this->session->set_userdata(array(
					"faile" => "Failed to Delete data"
				));				
			redirect(base_url()."index.php/testimonials");
		}
		
	}
	
	public function getClassOrder($detailId)
	{
		$data['currOrd']=$this->testimonials_model->getInfobyId($detailId);
		$data['classCnt']=$this->testimonials_model->getteachers();
		$data['detailId']=$detailId;
		$this->load->view("change-ord",$data);
	}
	
	public function saveOrder()
	{
		$rowId=$this->input->post("detailId");
		$params=array(
			"data_seq" => $this->input->post("ordPrty"),
		);
		$table="family_cms";
			//echo "<pre>";print_r($params);echo "</pre>";die();
		$videos=$this->testimonials_model->updateItems($table,$params,$rowId);
		if($videos == 1)
		{
			$this->session->set_userdata(array(
				"success" => "Successfully Data Updated"
			));
			redirect(base_url()."index.php/testimonials");
		}
		else
		{
			$this->session->set_userdata(array(
				"faile" => "Failed to Update data"
			));				
			redirect(base_url()."index.php/testimonials");
		}
	}
	
}
