<style>
.center{
	text-align:center;
}
</style>
<link href="<?php echo base_url()?>externals/css/plugins/dataTables/dataTables.bootstrap.css" rel="stylesheet">
<link href="<?php echo base_url()?>externals/css/plugins/dataTables/dataTables.responsive.css" rel="stylesheet">
<link href="<?php echo base_url()?>externals/css/plugins/dataTables/dataTables.tableTools.min.css" rel="stylesheet">
	<div class="row wrapper border-bottom white-bg page-heading">
		<div class="col-sm-4">
			<h2>Teachers</h2>
			<ol class="breadcrumb">
				<li>
					<a href="<?php echo base_url()?>">Dashboard</a>
				</li>
				<li class="active">
					<strong>Testimonials</strong>
				</li>
			</ol>
		</div>
		<div class="col-sm-4 pull-right">
			<h2>
			<a href="<?php echo base_url()?>index.php/testimonials/createtestimonials" class="btn btn-w-m btn-primary pull-right">Add Testimonial</a>
			</h2>
		</div>
	</div>
	<div class="row">
		<div class="col-lg-12">
			<div class="wrapper wrapper-content">
				<div class="row">
					<div class="ibox">                        
						<div class="ibox-content">
						<?php
						if(@$this->session->userdata("success") != '')
						{
						?>
							<div class="alert alert-success alert-dismissable">
                                <button aria-hidden="true" data-dismiss="alert" class="close" type="button">×</button>
                                <?php
								echo @$this->session->userdata("success");
								@$this->session->unset_userdata("success");
								?>
                            </div>
						<?php
						}
						if(@$this->session->userdata("fail") != '')
						{
						?>
							<div class="alert alert-danger alert-dismissable">
                                <button aria-hidden="true" data-dismiss="alert" class="close" type="button">×</button>
                                <?php
								echo @$this->session->userdata("fail");
								@$this->session->unset_userdata("fail");
								?>
                            </div>
						<?php
						}
						?>
							
							<table class="table table-striped table-bordered table-hover " id="editable" >
								<thead>
									<tr>
										<th class="center">S.No</th>
										<th class="center" style="width:10%;">Order</th>
										<th class="center" style="width:10%;">Name</th>										
										<th class="center" style="width:15%;">Designation</th>
										<th class="center" style="width:30%;">About</th>
										
										<th class="center" style="width:10%;">Actions</th>
									</tr>
								</thead>
								<tbody>
								<?php
								if(@sizeOf($testimonials) > 0)
								{
									for($a=0;$a<@sizeOf($testimonials);$a++)
									{
								?>
									<tr class="gradeX">
										<td class="center">
											<?php echo @($a+1);?>
										</td>
										<td class="center">											
											<?php echo @$testimonials[$a]->data_seq;?>&nbsp;&nbsp;<i class="fa fa-pencil bha-ord" id="<?php echo @$testimonials[$a]->id?>"></i>										
										</td>
										<td class="center">
											<?php echo @$testimonials[$a]->cms_title;?>
										</td>
										<td class="center">
											<?php echo @$testimonials[$a]->cms_designation;?>
										</td>
										<td class="center">
											<?php $bhanu=@strip_tags($testimonials[$a]->cms_desc);?>
											<?php echo @substr($bhanu,0,100);?>
										</td>
									
										<td class="center">
											<a href="<?php echo base_url()?>index.php/testimonials/edittestimonials/<?php echo @$testimonials[$a]->id;?>"><i class="fa fa-edit"></i></a> &nbsp;|&nbsp;
											<a href="<?php echo base_url()?>index.php/testimonials/deletetestimonials/<?php echo @$testimonials[$a]->id;?>"><i class="fa fa-trash"></i></a>
										</td>
									</tr>
								<?php
									}
								}								
								?>
								</tbody>
							</table>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>

<script src="<?php echo base_url()?>externals/js/plugins/jeditable/jquery.jeditable.js"></script>
<script src="<?php echo base_url()?>externals/js/plugins/dataTables/jquery.dataTables.js"></script>
<script src="<?php echo base_url()?>externals/js/plugins/dataTables/dataTables.bootstrap.js"></script>
<script src="<?php echo base_url()?>externals/js/plugins/dataTables/dataTables.responsive.js"></script>
<script src="<?php echo base_url()?>externals/js/plugins/dataTables/dataTables.tableTools.min.js"></script>
<script>
$(document).ready(function() {
	$('.dataTables-example').dataTable({
		responsive: true,
		"dom": 'T<"clear">lfrtip',
		"tableTools": {
			"sSwfPath": "js/plugins/dataTables/swf/copy_csv_xls_pdf.swf"
		}
	});

	/* Init DataTables */
	var oTable = $('#editable').dataTable();

	/* Apply the jEditable handlers to the table */
	/*oTable.$('td').editable( '../example_ajax.php', {
		"callback": function( sValue, y ) {
			var aPos = oTable.fnGetPosition( this );
			oTable.fnUpdate( sValue, aPos[0], aPos[1] );
		},
		"submitdata": function ( value, settings ) {
			return {
				"row_id": this.parentNode.getAttribute('id'),
				"column": oTable.fnGetPosition( this )[2]
			};
		},

		"width": "90%",
		"height": "100%"
	} );*/


});

function fnClickAddRow() {
	$('#editable').dataTable().fnAddData( [
		"Custom row",
		"New row",
		"New row",
		"New row",
		"New row" ] );

}
$(".bha-ord").click(function(){
	var clickId=$(this).attr("id");
	if(clickId !='')
	{
		$.ajax({
			type:"POST",
			url:'<?php echo base_url();?>index.php/teachers/getClassOrder/'+clickId,
			async:false,
			success:function(response){				
				$("#ordModal").modal();
				$("#ordData").html(response);
			}			
		})
		
	}
});
</script>


<!-- Description Modal Starts --> 
<div id="ordModal" class="modal fade" role="dialog">
	<div class="modal-dialog">
		<!-- Modal content-->
		<div class="modal-content" style="border-radius:0;">
		<div class="modal-header">
			<button type="button" class="close" data-dismiss="modal">&times;</button>
			<h4 class="modal-title">Description</h4>
		</div>
		<div class="modal-body">
			<div id="ordData"></div>		
		</div>
		<div class="modal-footer">
			
		</div>
    </div>
	
  </div>
</div>
<!-- End of Description Modal --> 