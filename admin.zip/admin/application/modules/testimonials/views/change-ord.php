<form method="POST" action="<?php echo base_url()?>index.php/testimonials/saveOrder" class="form-horizontal" enctype="multipart/form-data">
	<div class="form-group">
		<label class="col-sm-3 control-label">Order</label>
		<div class="col-sm-9">
			<select name="ordPrty" id="ordPrty" class="form-control" required>
				<option value="">Select Order</option>
				<?php
				if(@sizeOf($classCnt) > 0)
				{
					for($s=0;$s<@sizeOf($classCnt);$s++)
					{
						if(@$currOrd[0]->ordPrty == @$s+1)
						{
							$red="selected='selected'";
						}
						else
						{
							$red="";
						}
				?>
				<option <?php echo @$red;?> value="<?php echo @$s+1;?>"><?php echo @$s+1;?></option>
				<?php
					}
				}
				?>
			</select>
		</div>
	</div>
	<div class="hr-line-dashed"></div>
	<div class="form-group">
		<div class="col-sm-4 col-sm-offset-2">
			<input type="hidden" name="detailId" id="detailId" value="<?php echo @$detailId;?>"/>
			<button class="btn btn-primary" type="submit">Save</button>
		</div>
	</div>
</form>