<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Social_model extends CI_Model {

	
	public function getsocial()
	{
		$this->db->select("*")->from("social_links")->where(array("status" => 1));	
		$query=$this->db->get();
		//echo $this->db->last_query();die();
		if($query->num_rows() > 0)
		{
			return $query->result();
		}
		else{
			return array();
		}
	}
	
	public function storeItems($table,$params)
	{
		$query=$this->db->insert($table,$params);
		if($query)
		{
			return 1;
		}
		else{
			return 0;
		}
	}
	
	public function updateItems($table,$params,$bannerid)
	{
		$query=$this->db->update($table,$params,array("id" => $bannerid));
		if($query)
		{
			return 1;
		}
		else{
			return 0;
		}
	}
	
	public function getInfobyId($bannerid)
	{
		$query = $this->db->select("*")->from("social_links")->where("id",$bannerid)->get();
		if($query->num_rows() > 0)
		{
			return $query->result();
		}
		else{
			return array();
		}
	}
	
	public function deletesocial($bannerid)
	{
		$this->db->select("*")->from("social_links")->where(array("id" => $bannerid));
		$query=$this->db->get();
		//echo $this->db->last_query();die();
		if($query->num_rows() > 0)
		{
			$result=$query->result();		
			$delete=@unlink(FCPATH . 'uploads/aboutus/' . $result[0]->social_img);
			$deletequery=$this->db->delete("social_links",array("id" => $bannerid));
			if($deletequery)
			{
				return 1;
			}
			else
			{
				return 0;
			}
		}		
		else
		{
			return 0;
		}
	}
	
	public function removeExistsimage($bannerid)
	{
		$this->db->select("*")->from("social_links")->where(array("id" => $bannerid));
		$query=$this->db->get();
		//echo $this->db->last_query();die();
		if($query->num_rows() > 0)
		{
			$result=$query->result();		
			$delete=@unlink(FCPATH . 'uploads/aboutus/' . $result[0]->social_img);
			if($delete)
			{
				return 1;
			}
			else
			{
				return 0;
			}
		}
	}
}