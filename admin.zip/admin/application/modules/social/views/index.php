<style>
.center{
	text-align:center;
}
</style>

	<div class="row wrapper border-bottom white-bg page-heading">
		<div class="col-sm-4">
			<h2>Social Links</h2>
			<ol class="breadcrumb">
				<li>
					<a href="<?php echo base_url()?>">Dashboard</a>
				</li>
				<li class="active">
					<strong>social</strong>
				</li>
			</ol>
		</div>
		<div class="col-sm-4 pull-right">
			<h2>
				
				<a href="<?php echo base_url()?>index.php/social/createsocial" class="btn btn-w-m btn-primary pull-right">Add social</a>
				
			</h2>
		</div>
	</div>
	<div class="row">
		<div class="col-lg-12">
			<div class="wrapper wrapper-content">
				<div class="row">
					<div class="ibox">                        
						<div class="ibox-content">
						<?php
						if(@$this->session->userdata("success") != '')
						{
						?>
							<div class="alert alert-success alert-dismissable">
                                <button aria-hidden="true" data-dismiss="alert" class="close" type="button">×</button>
                                <?php
								echo @$this->session->userdata("success");
								@$this->session->unset_userdata("success");
								?>
                            </div>
						<?php
						}
						if(@$this->session->userdata("fail") != '')
						{
						?>
							<div class="alert alert-danger alert-dismissable">
                                <button aria-hidden="true" data-dismiss="alert" class="close" type="button">×</button>
                                <?php
								echo @$this->session->userdata("fail");
								@$this->session->unset_userdata("fail");
								?>
                            </div>
						<?php
						}
						?>
							<table class="table table-striped table-bordered table-hover " id="editable" >
								<thead>
									<tr>
										<th class="center">S.No</th>
										<th class="center">Social Link</th>
										<th class="center">Logo</th>
										<th class="center">Actions</th>
									</tr>
								</thead>
								<tbody>
								<?php
								//print_r($social);
								if(@sizeOf($social) > 0)
								{
									for($i=0;$i<sizeOf($social);$i++)
									{
								?>
									<tr class="gradeX">
										<td class="center"><?php echo @$i+1;?></td>
										<td class="center"><a target="_blank" href="<?php echo @$social[$i]->social_link;?>">View</a></td>
										<td class="center"><img style="background:#000;margin:0 auto;" src="<?php echo base_url();?>uploads/aboutus/<?php echo @$social[$i]->social_img;?>" class="img-responsive" /></td>
										
										<td class="center">
											<a href="<?php echo base_url()?>index.php/social/editsocial/<?php echo @$social[$i]->id;?>"><i class="fa fa-edit"></i></a> &nbsp;|&nbsp;
											<a href="<?php echo base_url()?>index.php/social/deletesocial/<?php echo @$social[$i]->id;?>"><i class="fa fa-trash"></i></a> 
										</td>
									</tr>
								<?php
									}
								}
								?>
								</tbody>
							</table>
						</div>
					</div>
				</div>
			</div>

