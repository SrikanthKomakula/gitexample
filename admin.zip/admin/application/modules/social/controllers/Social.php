<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Social extends MX_Controller {
	public function __construct()
	{
		parent::__construct();
		$this->load->model("social_model");
		//$this->load->model("category/category_model");
	}
	public function index()
	{
		if(@$this->session->userdata("is_logged_in") == 1)
		{
			$data["menu"]="soci";
			$this->load->view('dashboard/header',$data);
			$data["social"] = $this->social_model->getsocial();			
			$this->load->view('index', $data);
			$this->load->view('dashboard/footer');
		}
		else
		{
			redirect(base_url()."index.php/login");
		}
	}
	
	public function createsocial()
	{
		if(@$this->session->userdata("is_logged_in") == 1)
		{
			$data["menu"]="soci";
			$this->load->view('dashboard/header',$data);
			$this->load->view('create-item');
			$this->load->view('dashboard/footer');
		}
		else
		{
			redirect(base_url()."index.php/login");
		}
	}
	
	public function savesocial()
	{
		if($_FILES["mainImage"]["name"] !='')
		{
			$global=explode(".",$_FILES["mainImage"]["name"]);
			$banner_img=time().".".end($global);
		}
		else
		{
			$banner_img="";
		}
		$params = array(		
			
			"social_link" => $this->input->post("social_link"),			
			"social_img" => $banner_img,					
			"created_date" => @date("Y-m-d H:i:s"),
		);
		$table="social_links";
		$insocit = $this->social_model->storeItems($table,$params);
		if($insocit == 1)
		{
			@move_uploaded_file($_FILES["mainImage"]["tmp_name"],"uploads/aboutus/".$banner_img);
			$this->session->set_userdata(array(
				"success" => "Successfully Saved Data"
			));
			redirect(base_url()."index.php/social");
		}
		else{
			$this->session->set_userdata(array(
				"faile" => "Failed to save the data"
			));
			redirect(base_url()."index.php/social");
		}
	}
	
	public function editsocial($bannerid)
	{
		if(@$this->session->userdata("is_logged_in") == 1)
		{
			$data["menu"]="soci";
			$this->load->view('dashboard/header',$data);
			$data["info"]=$this->social_model->getInfobyId($bannerid);
			$data["bannerid"]=$bannerid;
			$this->load->view('edit-item',$data);
			$this->load->view('dashboard/footer');
		}
		else
		{
			redirect(base_url()."index.php/login");
		}
	}
	
	public function updatesocial()
	{
		if($this->session->userdata("is_logged_in") != 1)
		{
			redirect(base_url()."index.php/login");
		}
		else
		{	
			$bannerid=$this->input->post("socialid");
			
			if($_FILES["mainImage"]["name"] !='')
			{
				$category=explode(".",$_FILES["mainImage"]["name"]);
				$banner_img=time().".".end($category);
			
				$deleteExistimage=$this->social_model->removeExistsimage($bannerid);
								
				@move_uploaded_file($_FILES["mainImage"]["tmp_name"],"uploads/aboutus/".$banner_img);
			}
			else
			{
				$banner_img=$this->input->post("hiddenmainImage");
			}
			$params = array(		
				
				"social_link" => $this->input->post("social_link"),			
				"social_img" => $banner_img,	
			);
			//print_r($params);die();
			$table="social_links";
			$social_links=$this->social_model->updateItems($table,$params,$bannerid);
			if($social_links == 1)
			{
				$this->session->set_userdata(array(
					"success" => "Successfully Data Updated"
					));
				redirect(base_url()."index.php/social");
			}
			else
			{
				$this->session->set_userdata(array(
					"faile" => "Failed to Update data"
				));				
				redirect(base_url()."index.php/social");
			}
			
		}
	}
	
	public function deletesocial($bannerid)
	{
		//$bannerid=str_replace("_","=",base64_decode($bannerid));		
		$test=$this->social_model->deletesocial($bannerid);
		if($test == 1)
		{
			$this->session->set_userdata(array(
					"success" => "Successfully Deleted"
					));
				redirect(base_url()."index.php/social");
		}
		else
		{
			$this->session->set_userdata(array(
					"faile" => "Failed to Delete data"
				));				
			redirect(base_url()."index.php/social");
		}
		
	}
}
