<div class="row wrapper border-bottom white-bg page-heading">
		<div class="col-sm-4">
			<h2>User Property Details</h2>
			<ol class="breadcrumb">
				<li>
					<a href="<?php echo base_url()?>">Dashboard</a>
				</li>
				<li class="active">
					<strong>User Property Details</strong>
				</li>
			</ol>
		</div>
		
		</div>
		<div style="padding:20px">
		
		
		<div class="row">
		    <div class="col-sm-12">
		        <h3>User Details</h3>
    		    <div class="col-sm-6">
        		    <ul class="list-group">
                        <li class="list-group-item"><b>User ID :</b> <?php echo @$users_data[0]->user_id;?></li>
                        <li class="list-group-item"><b>User Name :</b> <?php echo @$users_data[0]->user_name;?></li>
                    </ul>
        		</div>
        		<div class="col-sm-6">
        		    <ul class="list-group">
        		         <li class="list-group-item"><b>User Email :</b> <?php echo @$users_data[0]->email;?></li>
                        <li class="list-group-item"><b>User Phone :</b> <?php echo @$users_data[0]->phone;?></li>
                    </ul>
        		</div>
    		</div>
		</div>
		
		<div class="row">
		    <div class="col-sm-12">
		        <h2>Properties Listing</h2>
		    </div>
		    <?php foreach($users_data as $item){ ?>
		    <div class="col-sm-12 propert_det">
		        <h3>User Details</h3>
    		    <div class="col-sm-6">
        		    <ul class="list-group">
                        <li class="list-group-item"><b>Property Name :</b> <?php echo $item->property_name;?></li>
                        <li class="list-group-item"><b>Property Type :</b> <?php echo $item->property_type;?></li>
                        <li class="list-group-item"><b>Property Status :</b> <?php echo $item->property_status;?></li>
                        <li class="list-group-item"><b>Area  :</b><?php echo $item->area_value;?> <?php echo $item->area_units;?></li>
                        <li class="list-group-item"><b>Property Facing :</b> <?php echo $item->facing;?></li>
                        <li class="list-group-item"><b>Property Price :</b> <?php echo $item->property_price;?></li>
                        <li class="list-group-item"><b>Property Approved By :</b> <?php echo $item->approved_by;?></li>
                        <li class="list-group-item"><b>Property Position :</b> <?php echo $item->position_of_flat;?></li>
                        <li class="list-group-item"><b>Time to Handover :</b> <?php echo $item->time_to_handover;?></li>
                        <li class="list-group-item"><b>GST Charges :</b> <?php echo $item->gst_charges;?></li>
                        <li class="list-group-item"><b>Friendly Address :</b> <?php echo $item->friendly_addr;?></li>
                        <li class="list-group-item"><b>Property Place :</b> <?php echo $item->place;?></li>
                        <li class="list-group-item"><b>Property District :</b> <?php echo $item->district;?></li>
                        <li class="list-group-item"><b>Property State :</b> <?php echo $item->state;?></li>
                        <?php if($item->property_type != "plot" && $item->property_type != "agriculture_lands" ){  ?>
                        <li class="list-group-item"><b>Bedrooms :</b> <?php echo $item->bedrooms;?> (<?php echo $item->bed_room_size_1.'  '.$item->bed_room_size_2.'  '.$item->bed_room_size_3.'  '.$item->bed_room_size_4 ;?>)</li>
                        <li class="list-group-item"><b>Bathrooms :</b> <?php echo $item->bathrooms;?></li>
                        <li class="list-group-item"><b>Balcony :</b> <?php echo $item->balcony;?></li>
                        <li class="list-group-item"><b>Parking :</b> <?php echo $item->parking;?> (<?php echo $item->car_coverd;?> Car(s) Covered)</li>
                        <li class="list-group-item"><b>Balcony :</b> <?php echo $item->balcony;?></li>
                        <li class="list-group-item"><b>Balcony :</b> <?php echo $item->balcony;?></li>
                        <?php } ?>
                    </ul>
        		</div>
        		<div class="col-sm-6">
        		    <ul class="list-group">
        		        
        		        <?php $prop_id = $item->prop_id;?>
        		        
        		        <?php 	$query = $this->db->select("*")->from("property_images")->where("property_id", $prop_id)->get();
        		        $results = $query->result_array();
        		        foreach($results as $img){
        		        ?>
        		         <img src="https://www.hikeassets.com/uploads/properties/<?php echo $img['file_name']; ?>" class="property_detail_img img-fluid"></li>
        		         <?php } ?>
                    </ul>
        		</div>
    		</div>
    		<?php } ?>
		</div>
		</div>
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		