<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Users_model extends CI_Model {

    function __construct() { 
        // Set table name 
        $this->table = 'customers'; 
        $this->imgTbl = 'property_images';
         $this->galleryTbl   = 'properties'; 
    } 
    

    	public function getTotalInfo()
	{
    	  $this->db->select('*')
         ->from('customers');
         
        
        $query = $this->db->get();
	    
		if($query->num_rows() > 0)
		{
			return $query->result();
		}
		else{
			return array();
		}
	}

	public function updateItems($table,$params,$bannerid)
	{
		$query=$this->db->update($table,$params,array("id" => $bannerid));
		if($query)
		{
			return 1;
		}
		else{
			return 0;
		}
	}
	
	public function getTotalInfobyId($id)
	{
	    $this->db->select('properties.*,properties.id as prop_id, customers.*');
        $this->db->from('properties');
        $this->db->join('customers', 'customers.id = properties.user_id');
        $this->db->where('properties.user_id',$id);
        $query = $this->db->get();
	    
		if($query->num_rows() > 0)
		{
			return $query->result();
		}
		else{
			return array();
		}
	}
	
	public function deleteuser($bannerid)
	{		
		$this->db->select("*")->from("customers")->where(array("id" => $bannerid));		
		$query=$this->db->get();
		
		if($query->num_rows() == 1)
		{
			$result=$query->result();
			@unlink(FCPATH . 'uploads/customers/' . $result[0]->thumbnail);					
		}
		$deletequery=$this->db->delete("customers",array("id" => $bannerid));
		/*$deletequery=$this->db->delete("properties",array("user_id" => $bannerid));*/
		
		
		if($deletequery)
		{
			return 1;
		}
		else
		{
			return 0;
		}
	}
		
	public function deleteproperties($bannerid)
	{
	    $deletequery=$this->db->delete("properties",array("user_id" => $bannerid));
	    if($deletequery)
		{
			return 1;
		}
		else
		{
			return 0;
		}
	}

      /* 
     * Delete image data from the database 
     * @param array filter data based on the passed parameter 
     */ 
    public function deleteImage($con){ 
        // Delete image data 
        $delete = $this->db->delete($this->imgTbl, $con); 
         
        // Return the status 
        return $delete?true:false; 
    } 
    
    
    public function getpropertiesbyuserId($id)
	{
		$this->db->select("*")->from("properties");
		/*$this->db->join('clients','clients.ClientID = products.Brand');*/
		$this->db->where(array("user_id" => $id));	
		$query=$this->db->get();
		
		if($query->num_rows() > 0)
		{
			return $query->result_array();
		}
		else{
			return array();
		}
	}
	
    
    
	 public function getPropertybyID($id = ''){ 
        $this->db->select("*, (SELECT file_name FROM ".$this->imgTbl." WHERE property_id = ".$this->galleryTbl.".id ORDER BY id DESC LIMIT 1) as default_image"); 
        $this->db->from($this->galleryTbl); 
        if($id){ 
            $this->db->where('id', $id); 
            $query  = $this->db->get(); 
            $result = ($query->num_rows() > 0)?$query->row_array():array(); 
             
            if(!empty($result)){ 
                $this->db->select('*'); 
                $this->db->from($this->imgTbl); 
                $this->db->where('property_id', $result['id']); 
                $this->db->order_by('id', 'desc'); 
                $query  = $this->db->get(); 
                $result2 = ($query->num_rows() > 0)?$query->result_array():array(); 
                $result['images'] = $result2;  
                
                
            }  
        }else{ 
            $this->db->order_by('id', 'desc'); 
            $query  = $this->db->get(); 
            $result = ($query->num_rows() > 0)?$query->result_array():array(); 
        } 
         
        // return fetched data 
        return !empty($result)?$result:false; 
    } 
    
	
}