<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Users extends MX_Controller {
	public function __construct()
	{
		parent::__construct();
		$this->load->model("users_model");
		/*$this->load->model("services/services_model");*/
	}
	public function index()
	{
			if(@$this->session->userdata("is_logged_in") == 1)
		{
		    $bannerid=1;
			$data["menu"]="user";
			$this->load->view('dashboard/header',$data);
			$data["users_data"]=$this->users_model->getTotalInfo();
			$data["bannerid"]=$bannerid;
			$this->load->view('index',$data);
			$this->load->view('dashboard/footer');
		}
		else
		{ 
			redirect(base_url()."index.php/login");
		}
	}
	
		public function user_data($id)
	{
			if(@$this->session->userdata("is_logged_in") == 1)
		{
		    $bannerid=1;
			$data["menu"]="properties";
			$this->load->view('dashboard/header',$data);
			$data["users_data"]=$this->users_model->getTotalInfobyId($id);
			$data["bannerid"]=$bannerid;
			$this->load->view('user_data',$data);
			$this->load->view('dashboard/footer');
		}
		else
		{
			redirect(base_url()."index.php/login");
		}
	}
	

	public function updatebanners()
	{
		if($this->session->userdata("is_logged_in") != 1)
		{
			redirect(base_url()."index.php/login");
		}
		else
		{	
			$bannerid=$this->input->post("bannersid");
			
			

			$params=array(
				 "banner_title" => $this->input->post("banner_title"),
				"banner_content" => $this->input->post("banner_content"), 
									
			);
			//print_r($params);die();
			$table="banners";
			$banners=$this->banners_model->updateItems($table,$params,$bannerid);
			if($banners == 1)
			{
				$this->session->set_userdata(array(
					"success" => "Successfully Data Updated"
				));
				redirect(base_url()."index.php/banners");
			}
			else
			{
				$this->session->set_userdata(array(
					"faile" => "Failed to Update data"
				));				
				redirect(base_url()."index.php/banners");
			}
			
		}
	}
	
	
		public function deleteuser($bannerid)
	{
		$test=$this->users_model->deleteuser($bannerid);
		
			$properties=$this->users_model->getpropertiesbyuserId($bannerid);
			
			$delete=$this->users_model->deleteproperties($bannerid);
			
		
		if($delete){ 
		    
		    foreach($properties as $prop){
		        
		        
		        
		        $id = $prop['id'];
		      
		      
		       
            $galleryData = $this->users_model->getPropertybyID($id); 
             //print_r($galleryData);exit;
            // Delete gallery data 
            $delete = $this->users_model->delete($id); 
             
            if($delete){ 
                // Delete images data  
                $condition = array('property_id' => $id);  
                $deleteImg = $this->users_model->deleteImage($condition); 
                  
                  /*Deleting thumbnail*/
                  @unlink('uploads/properties/'.$galleryData['thumbnail']);
                  
                // Remove files from the server  
                if(!empty($galleryData['images'])){  
                    foreach($galleryData['images'] as $img){  
                        @unlink('uploads/properties/'.$img['file_name']);  
                    }  
                }
                
                 
                $this->session->set_userdata(array(
				"success" => "Successfully Deleted"
			));
            }else{ 
                	$this->session->set_userdata(array(
					"faile" => "Failed to Delete data"
				));	
            } 
        
		    }
		    
                $this->session->set_userdata(array(
				"success" => "Successfully Deleted"
			));
            }
		else
		{
			$this->session->set_userdata(array(
					"faile" => "Failed to Delete data"
				));				
		  
		}
		redirect(base_url()."index.php/properties");
		
	}

}
