<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Login_model extends CI_Model {

	public function checkUser($params)
	{
		$query=$this->db->select("*")->from("users")->where(array("email" => $params["email"],"password" => $params["password"], "status" => 1))->where_in("usertype",array(1,2,3))->get();
		//echo $this->db->last_query();
		if($query->num_rows() > 0)
		{
			return $query->result();
		}
		else
		{
			return array();
		}
	}
	
	public function getUserDetailsByEmail($email)
	{
		$this->db->select("*")->from('users')->where("email",$email);
		$query = $this->db->get();
		//echo $this->db->last_query();die();
		if($query->num_rows() == 1)
		{
			return $query->result();
		}
		else
		{
			return array();
		}
	}
	
	public function getUserDetails($email)
	{
		$this->db->select("*")->from("users")->where(array("usertype" => 1,"email" => $email));
		$query=$this->db->get();
		if($query->num_rows() > 0)
		{
			return $query->result();
		}
		else{
			return array();
		}
	}
	
	public function updateNewPassword($params,$email)
	{
		$query=$this->db->update("users",$params,array("email" => $email));
		if($query)
		{
			return 1;
		}
		else{
			return 0;
		}
	}
	
	public function getSuperAdminUserDetails()
	{
		$this->db->select("email")->from("users")->where(array("usertype" => 1,"status" => 1));
		$query=$this->db->get();
		if($query->num_rows() > 0)
		{
			return $query->result();
		}
		else{
			return array();
		}
	}
	
}