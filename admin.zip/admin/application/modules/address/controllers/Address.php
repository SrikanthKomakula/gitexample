<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Address extends MX_Controller {
	public function __construct()
	{
		parent::__construct();
		$this->load->model("address_model");
		//$this->load->model("category/category_model");
	}
	public function index()
	{
		if(@$this->session->userdata("is_logged_in") == 1)
		{
			$data["menu"]="addr";
			$this->load->view('dashboard/header',$data);
			$data["address"] = $this->address_model->getaddress();			
			$this->load->view('index', $data);
			$this->load->view('dashboard/footer');
		}
		else
		{
			redirect(base_url()."index.php/login");
		}
	}
	
	public function createaddress()
	{
		if(@$this->session->userdata("is_logged_in") == 1)
		{
			$data["menu"]="addr";
			$this->load->view('dashboard/header',$data);
			$this->load->view('create-item');
			$this->load->view('dashboard/footer');
		}
		else
		{
			redirect(base_url()."index.php/login");
		}
	}
	
	public function saveaddress()
	{
		if($_FILES["mainImage"]["name"] !='')
		{
			$global=explode(".",$_FILES["mainImage"]["name"]);
			$banner_img=time().".".end($global);
		}
		else
		{
			$banner_img="";
		}
		$params = array(			
			"country" => $this->input->post("country"),			
			"company_address" => $this->input->post("company_address"),			
			"company_email" => $this->input->post("company_email"),			
			"compnay_mobile" => $this->input->post("compnay_phone"),			
			"map_lat" => $this->input->post("map_lat"),			
			"country_img" =>$banner_img,			
			"created_date" => @date("Y-m-d H:i:s"),
		);
		$table="address";
		$inaddrt = $this->address_model->storeItems($table,$params);
		if($inaddrt == 1)
		{
			@move_uploaded_file($_FILES["mainImage"]["tmp_name"],"uploads/aboutus/".$banner_img);
			$this->session->set_userdata(array(
				"success" => "Successfully Saved Data"
			));
			redirect(base_url()."index.php/address");
		}
		else{
			$this->session->set_userdata(array(
				"faile" => "Failed to save the data"
			));
			redirect(base_url()."index.php/address");
		}
	}
	
	public function editaddress($bannerid)
	{
		if(@$this->session->userdata("is_logged_in") == 1)
		{
			$data["menu"]="addr";
			$this->load->view('dashboard/header',$data);
			$data["info"]=$this->address_model->getInfobyId($bannerid);
			$data["bannerid"]=$bannerid;
			$this->load->view('edit-item',$data);
			$this->load->view('dashboard/footer');
		}
		else
		{
			redirect(base_url()."index.php/login");
		}
	}
	
	public function updateaddress()
	{
		if($this->session->userdata("is_logged_in") != 1)
		{
			redirect(base_url()."index.php/login");
		}
		else
		{	
			$bannerid=$this->input->post("addressid");
			if(@$_FILES["mainImage"]["name"] != '')
			{
				$category=explode(".",$_FILES["mainImage"]["name"]);
				$banner_img=time().".".end($category);
			
				$deleteExistimage=$this->address_model->removeExistsimage($bannerid);
								
				@move_uploaded_file($_FILES["mainImage"]["tmp_name"],"uploads/aboutus/".$banner_img);
						
			}
			else
			{
				$banner_img=$this->input->post("hiddenmainImage");
			}
			$params=array(
				"country" => $this->input->post("country"),			
				"company_address" => $this->input->post("company_address"),			
				"company_email" => $this->input->post("company_email"),			
				"compnay_mobile" => $this->input->post("compnay_mobile"),			
				"map_lat" => $this->input->post("map_lat"),			
				"country_img" =>$banner_img,			
			);
			//print_r($params);die();
			$table="address";
			$address=$this->address_model->updateItems($table,$params,$bannerid);
			if($address == 1)
			{
				$this->session->set_userdata(array(
					"success" => "Successfully Data Updated"
					));
				redirect(base_url()."index.php/address");
			}
			else
			{
				$this->session->set_userdata(array(
					"faile" => "Failed to Update data"
				));				
				redirect(base_url()."index.php/address");
			}
			
		}
	}
	
	public function deleteaddress($bannerid)
	{
		//$bannerid=str_replace("_","=",base64_decode($bannerid));		
		$test=$this->address_model->deleteaddress($bannerid);
		if($test == 1)
		{
			$this->session->set_userdata(array(
					"success" => "Successfully Deleted"
					));
				redirect(base_url()."index.php/address");
		}
		else
		{
			$this->session->set_userdata(array(
					"faile" => "Failed to Delete data"
				));				
			redirect(base_url()."index.php/address");
		}
		
	}
}
