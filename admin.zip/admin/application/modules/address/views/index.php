<style>
.center{
	text-align:center;
}
</style>

	<div class="row wrapper border-bottom white-bg page-heading">
		<div class="col-sm-4">
			<h2>Contact Address</h2>
			<ol class="breadcrumb">
				<li>
					<a href="<?php echo base_url()?>">Dashboard</a>
				</li>
				<li class="active">
					<strong>Address</strong>
				</li>
			</ol>
		</div>
		<div class="col-sm-4 pull-right">
			<h2>

				<a href="<?php echo base_url()?>index.php/address/createaddress" class="btn btn-w-m btn-primary pull-right">Add Address</a>
		
			</h2>
		</div>
	</div>
	<div class="row">
		<div class="col-lg-12">
			<div class="wrapper wrapper-content">
				<div class="row">
					<div class="ibox">                        
						<div class="ibox-content">
						<?php
						if(@$this->session->userdata("success") != '')
						{
						?>
							<div class="alert alert-success alert-dismissable">
                                <button aria-hidden="true" data-dismiss="alert" class="close" type="button">×</button>
                                <?php
								echo @$this->session->userdata("success");
								@$this->session->unset_userdata("success");
								?>
                            </div>
						<?php
						}
						if(@$this->session->userdata("fail") != '')
						{
						?>
							<div class="alert alert-danger alert-dismissable">
                                <button aria-hidden="true" data-dismiss="alert" class="close" type="button">×</button>
                                <?php
								echo @$this->session->userdata("fail");
								@$this->session->unset_userdata("fail");
								?>
                            </div>
						<?php
						}
						?>
							<table class="table table-striped table-bordered table-hover " id="editable" >
								<thead>
									<tr>
										<th class="center">S.No</th>
										<th class="center">Country</th>
										<th class="center">Address</th>
										<th class="center">Email</th>
										<th class="center">Phone</th>
										<th class="center">Actions</th>
									</tr>
								</thead>
								<tbody>
								<?php
								if(@sizeOf($address) > 0)
								{
									for($i=0;$i<sizeOf($address);$i++)
									{
								?>
									<tr class="gradeX">
										<td class="center"><?php echo ($i+1)?></td>	
										<td class="center">											
											<img class="img-responsive" style="width:150px;margin:0 auto;" src="<?php echo base_url();?>uploads/aboutus/<?php echo @$address[$i]->country_img;?>"><br>
											<b style="color:#428BCA"><?php echo @$address[$i]->country;?></b>
										</td>
										<td class="center"><?php echo @$address[$i]->company_address;?></td>
										<td class="center"><?php echo @$address[$i]->company_email;?></td>
										<td class="center"><?php echo @$address[$i]->compnay_mobile;?></td>
										<td class="center">
											<a href="<?php echo base_url()?>index.php/address/editaddress/<?php echo @$address[$i]->id;?>"><i class="fa fa-edit"></i></a> 
										</td>
									</tr>
								<?php
									}
								}
								?>
								</tbody>
							</table>
						</div>
					</div>
				</div>
			</div>

